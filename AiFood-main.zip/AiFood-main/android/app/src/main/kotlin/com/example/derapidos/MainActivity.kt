package com.highapp.co.uk.aifood

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
