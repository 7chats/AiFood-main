import 'dart:async';

import 'package:aifood/View/NavigationBar/navigationbar_screen.dart';
import 'package:aifood/user_prefs/user_prefs.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../Onboarding/onboarding_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  initState() {
    super.initState();
    goToNextScreen();
    // Timer(const Duration(seconds: 3), () {
    //   Navigator.of(context).pushReplacement(
    //       MaterialPageRoute(builder: (_) => const OnboardingScreen()));
    // });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // CustomText(
            //   text: "Azar    آزر",
            //   fontSize: 36.sp,
            //   fontWeight: FontWeight.w400,
            //   fontColor: Color(0xff196CA8),
            // ),
            RichText(
              textScaleFactor: 3,
              text: TextSpan(
                // style: TextStyle(color: Colors.black, fontSize: 36.sp),
                children: <TextSpan>[
                  TextSpan(text: 'A', style: TextStyle(color: Colors.green)),
                  TextSpan(text: 'i', style: TextStyle(color: Colors.red)),
                  TextSpan(text: 'Food', style: TextStyle(color: Colors.green))
                ],
              ),
            ),
            // Image.asset(
            //   "assets/images/Ai texi Driver Side Images/SplashScreen.png",
            //   fit: BoxFit.fill,
            //   height: 46.h,
            //   width: 136.w,
            //   alignment: Alignment.center,
            // ),
          ],
        ),
      ),
    );
  }

  goToNextScreen() {
    bool? isLogin = UserPreferences.getLoginCheck() ?? false;
    var splashDuration = const Duration(seconds: 5);
    Timer(splashDuration, () {
      if (isLogin) Get.off(const NavigationbarScreen());
      if (!isLogin) Get.off(const OnboardingScreen());
    });
  }
}
