import 'package:aifood/View/EnableLocation/enable_location_screen.dart';
import 'package:aifood/View/NavigationBar/navigationbar_screen.dart';
import 'package:aifood/services/api_services.dart';
import 'package:aifood/user_prefs/user_prefs.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import '../Custom Widget/button.dart';
import '../Custom Widget/custom_text.dart';
import '../SignUp/sign_up_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool isSelected = false;
  var _isloading = false;
  bool _isObscure = true;

  String? email = '';
  String? password = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.only(left: 30.w, right: 30.w),
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 30.h),
                Image.asset(
                  "assets/images/logo.png",
                  height: 100.h,
                  width: 300.w,
                ),
                SizedBox(height: 50.h),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      text: "Hi, Welcome Back!",
                      textAlign: TextAlign.start,
                      fontColor: const Color(0xff444444),
                      fontSize: 23.sp,
                      fontWeight: FontWeight.w500,
                    ),
                    SizedBox(height: 10.h),
                    CustomText(
                      text: "Login in to your account",
                      fontColor: const Color(0xffC0C0C0),
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                    ),
                    SizedBox(height: 30.h),
                    Container(
                      height: 55.h,
                      width: double.maxFinite.w,
                      decoration: BoxDecoration(
                        color: const Color(0xffFFFFFF),
                        borderRadius: BorderRadius.circular(47.0.r),
                        border: Border.all(
                          width: 1,
                          color: const Color(0xffE5E5E5),
                        ),
                        boxShadow: const [
                          BoxShadow(
                            offset: Offset(0, 0),
                            blurRadius: 5.0,
                            spreadRadius: 0.0,
                            color: Color(0xffE5E5E5),
                          ),
                        ],
                      ),
                      child: TextField(
                        cursorColor: const Color(0xffC0C0C0),
                        decoration: InputDecoration(
                          prefixIcon: const Icon(
                            FontAwesomeIcons.envelope,
                            size: 17,
                            color: Color(0xffC0C0C0),
                          ),
                          fillColor: Colors.white,
                          filled: true,
                          border: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.circular(47.0.r),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.circular(470.r),
                          ),
                          hintText: "Your Email",
                          hintStyle: TextStyle(
                            color: const Color(0xff9C0C0C0),
                            fontFamily: 'DMSans',
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        onChanged: (value) {
                          email = value;
                        },
                      ),
                    ),
                    SizedBox(height: 20.h),
                    Container(
                      height: 55.h,
                      width: double.maxFinite.w,
                      decoration: BoxDecoration(
                        color: const Color(0xffFFFFFF),
                        borderRadius: BorderRadius.circular(47.0.r),
                        border: Border.all(
                          width: 1,
                          color: const Color(0xffE5E5E5),
                        ),
                        boxShadow: const [
                          BoxShadow(
                            offset: Offset(0, 0),
                            blurRadius: 5.0,
                            spreadRadius: 0.0,
                            color: Color(0xffE5E5E5),
                          ),
                        ],
                      ),
                      child: TextField(
                        obscureText: _isObscure,
                        cursorColor: const Color(0xffC0C0C0),
                        decoration: InputDecoration(
                          prefixIcon: const ImageIcon(
                            AssetImage("assets/images/lock.png"),
                            color: Color(0xffC0C0C0),
                            size: 18,
                          ),
                          fillColor: Colors.white,
                          filled: true,
                          suffixIcon: IconButton(
                            icon: Icon(
                              _isObscure
                                  ? FontAwesomeIcons.eye
                                  : FontAwesomeIcons.eyeSlash,
                              size: 15,
                              color: const Color(0xff9C0C0C0),
                            ),
                            onPressed: () {
                              setState(() {
                                _isObscure = !_isObscure;
                              });
                            },
                          ),
                          border: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.circular(47.0.r),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.circular(47.0.r),
                          ),
                          hintText: "Password",
                          hintStyle: TextStyle(
                            color: const Color(0xff9C0C0C0),
                            fontFamily: 'DMSans',
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        onChanged: (value) {
                          password = value;
                        },
                      ),
                    ),
                    SizedBox(height: 24.h),
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     CustomText(
                    //       text: "Forget Password?",
                    //       fontColor: const Color(0xff5D3EBD),
                    //       fontWeight: FontWeight.w500,
                    //       fontSize: 12.sp,
                    //     ),
                    //   ],
                    // ),
                    SizedBox(height: 30.h),
                    _isloading
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              CircularProgressIndicator(),
                            ],
                          )
                        : Container(
                            height: 55.h,
                            width: double.maxFinite.w,
                            child: MyCustomButton(
                              onPressed: () async {
                                _isloading = true;
                                _redraw();
                                var res =
                                    await ApiServices.login(email, password);
                                _isloading = false;
                                _redraw();
                                if (res!) {
                                  Get.off(const EnableLocationScreen());
                                }
                              },
                              height: 55.h,
                              width: double.maxFinite.w,
                              buttonColor: const Color(0xffEC2547),
                              text: "Login",
                              textColor: const Color(0xffFFFFFF),
                              fontSize: 14.sp,
                            ),
                          ),
                    SizedBox(height: 30.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomText(
                          text: "Don’t have an account?",
                          fontColor: const Color(0xffC0C0C0),
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w500,
                        ),
                        GestureDetector(
                          onTap: () {
                            Get.off(const SignUpScreen());
                          },
                          child: CustomText(
                            text: "Sign Up",
                            fontColor: const Color(0xff5D3EBD),
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 30.h),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: ()  {
                            // await UserPreferences.setUserData("");
                            // UserPreferences.setLoginCheck(false);
                            UserPreferences.setLoginCheck(false);
                            Navigator.of(context)
                                .pushAndRemoveUntil(
                                MaterialPageRoute(
                                  builder:
                                      (context) =>
                                          NavigationbarScreen(),
                                ),
                                    (Route<dynamic>
                                route) =>
                                false);
                            },
                          child: CustomText(
                            text: "Skip",
                            fontColor: const Color(0xff5D3EBD),
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 20.h),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _redraw() {
    if (kDebugMode) setState(() {});
  }
}
