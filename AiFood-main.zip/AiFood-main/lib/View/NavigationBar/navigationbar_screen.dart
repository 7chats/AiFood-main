import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../Explore/explore_screen.dart';
import '../Home/home_screen.dart';
import '../My Cart/mycart_screen.dart';
import '../Orders/orders_screen.dart';
import '../Profile/profile.dart';

class NavigationbarScreen extends StatefulWidget {
  const NavigationbarScreen({Key? key}) : super(key: key);

  @override
  State<NavigationbarScreen> createState() => _NavigationbarScreenState();
}

class _NavigationbarScreenState extends State<NavigationbarScreen> {
  @override
  void initState() {

    super.initState();
  }
  int _selectedIndex = 0;
  final screen = [
    const HomeScreen(),
    const ExploreScreen(),
    const OrdersScreen(),
    const MycartScreen(),
    const Profile(),
  ];

  _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: screen.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(20.0.sp),
          bottomRight: Radius.circular(20.0.sp),
        ),
        child: SizedBox(
          height: 80.h,
          child: BottomNavigationBar(
            unselectedItemColor: const Color(0xff9098B1),
            backgroundColor: const Color(0xff5D3EBF),
            selectedLabelStyle: TextStyle(
                fontWeight: FontWeight.w500,
                fontFamily: "DMSans",
                fontSize: 8.sp),
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.home_outlined,
                  size: 24,
                ),
                label: "Home",
                backgroundColor: Color(0xffFFFFFF),
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.favorite_border,
                  size: 24,
                ),
                label: "Explore",
                backgroundColor: Color(0xffFFFFFF),
              ),
              BottomNavigationBarItem(
                icon: ImageIcon(
                    size: 24,
                    AssetImage(
                      "assets/images/Order.png",
                    )),
                label: "Orders",
                backgroundColor: Color(0xffFFFFFF),
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.shopping_cart_outlined,
                  size: 24,
                ),
                label: "Cart",
                backgroundColor: Color(0xffFFFFFF),
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  // Icons.person_2_outlined,
                  Icons.person,
                  size: 24,
                ),
                label: "Profile",
                backgroundColor: Color(0xffFFFFFF),
              ),
            ],
            type: BottomNavigationBarType.shifting,
            currentIndex: _selectedIndex,
            selectedItemColor: const Color(0xffe5d3ebf),
            iconSize: 24,
            onTap: _onItemTapped,
          ),
        ),
      ),
    );
  }
}
