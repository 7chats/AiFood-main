import 'package:aifood/View/Store%20Details/service_products.dart';
import 'package:aifood/controllers/favorites_controller.dart';
import 'package:aifood/controllers/home_controller.dart';
import 'package:aifood/models/categories.dart';
import 'package:aifood/models/restaurant_detail.dart';
import 'package:aifood/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import '../Custom Widget/custom_text.dart';
import '../Product Details/product_details.dart';
import '../list/burger_list.dart';
import 'Services/Burgers.dart';
import 'Services/Chicken.dart';
import 'Services/Meale.dart';
import 'Services/Promo.dart';

class StoreDetailScreen extends StatefulWidget {
  const StoreDetailScreen({Key? key}) : super(key: key);

  @override
  State<StoreDetailScreen> createState() => _StoreDetailScreenState();
}

class _StoreDetailScreenState extends State<StoreDetailScreen> {
  int currentSelected = 0;
  // List<String> jobsTypes = [
  //   "Promo",
  //   "Meals",
  //   "Burgers",
  //   "Chicken",
  // ];
  // List screens = [
  //   const Promo(),
  //   const Meale(),
  //   const Burgers(),
  //   const Chicken(),
  // ];
  bool selected = true;
  var homeController = Get.put(HomeController());
  var favoritesController = Get.put(FavoritesController());

  // String? currentCategoryId = '';

  @override
  initState() {
    homeController.getStoreDetail();
    // setState(() {});
    super.initState();
  }

  makeItFavorite(BuildContext context, StoreProduct product) async {
    showLoading(context);
    favoritesController.assignProductFromStoreDetail(product);
    var res1 = await favoritesController.addToFavorites();
    await Future.delayed(const Duration(seconds: 1));
    Get.back();
    if (res1!) {
      showSnackBar(context, 'Added to Favorite Successfully');
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetX<HomeController>(
      builder: (homeController) {
        return Scaffold(
          backgroundColor: Colors.white,
          body: homeController.rdLoading.value
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                  child: Stack(
                    children: <Widget>[
                      Container(
                        child: Column(
                          children: [
                            SizedBox(
                              height: 320.h,
                              child: Stack(
                                children: [
                                  Container(
                                    height: 265.h,
                                    width: 375.w,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(8.r),
                                        topLeft: Radius.circular(8.r),
                                        bottomLeft: Radius.zero,
                                        bottomRight: Radius.zero,
                                      ),
                                      image: DecorationImage(
                                        // image: AssetImage("assets/images/StoreImage.png"),
                                        image: NetworkImage(
                                          "${homeController.restaurantDetails!. //
                                              data!.marketDetails!.bannerImage}",
                                        ),
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                              left: 30, right: 30, bottom: 130)
                                          .r,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          InkWell(
                                            onTap: () {
                                              Get.back();
                                            },
                                            child: const Padding(
                                              padding: EdgeInsets.all(8.0),
                                              child: Icon(
                                                Icons.arrow_back_ios_new,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            height: 30.h,
                                            width: 30.w,
                                            decoration: BoxDecoration(
                                              color: const Color(0xffFEBD00),
                                              borderRadius:
                                                  BorderRadius.circular(3.r),
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0).r,
                                              child: const Icon(
                                                Icons.favorite_border,
                                                size: 14,
                                                color: Colors.white,
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    top: 217.h,
                                    left: 40.w,
                                    child: Container(
                                      height: 87.h,
                                      width: 295.w,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(5.r),
                                        boxShadow: const [
                                          BoxShadow(
                                            offset: Offset(0, 0),
                                            blurRadius: 5.0,
                                            color: Color(0xffE5E5E5),
                                          ),
                                        ],
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0).r,
                                        child: Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                CustomText(
                                                  text: "${homeController.restaurantDetails!. //
                                                      data!.marketDetails!.name}",
                                                  // text: "Burger King",
                                                  fontColor:
                                                      const Color(0xff444444),
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14.sp,
                                                ),
                                                CustomText(
                                                  text: "${homeController.restaurantDetails!. //
                                                      data!.marketDetails!.openStatus}",
                                                  // text: "OPEN",
                                                  fontColor:
                                                      const Color(0xffEC2547),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 8.sp,
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 4.h),
                                            Row(
                                              children: [
                                                const Icon(
                                                  Icons.location_on_outlined,
                                                  size: 9,
                                                  color: Color(0xff9098B1),
                                                ),
                                                CustomText(
                                                  text: "${homeController.restaurantDetails!. //
                                                      data!.marketDetails!.address}",
                                                  // text: "Majeedhee Magu Rd, Malé, Maldives",
                                                  fontColor:
                                                      const Color(0xff9098B1),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 10.sp,
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 8.h),
                                            Row(
                                              children: [
                                                const ImageIcon(
                                                  AssetImage(
                                                      "assets/images/time.png"),
                                                  size: 10,
                                                  color: Color(0xff9A9A9A),
                                                ),
                                                CustomText(
                                                  // text: "${homeController.restaurantDetails!. //
                                                  //     data!.marketDetails!.name}",
                                                  text: "10 AM - 22 PM",
                                                  fontColor:
                                                      const Color(0xff9A9A9A),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 8.sp,
                                                ),
                                                CustomText(
                                                  text: "(Today)",
                                                  fontColor:
                                                      const Color(0xff9A9A9A),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 8.sp,
                                                ),
                                                const Icon(
                                                  Icons
                                                      .keyboard_arrow_down_sharp,
                                                  size: 10,
                                                  color: Color(0xff9098B1),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 8.h),
                                            Row(
                                              children: [
                                                const Icon(
                                                  Icons.star,
                                                  color: Color(0xffFFC107),
                                                  size: 8,
                                                ),
                                                // SizedBox(width: 16.w),
                                                CustomText(
                                                  text: "${homeController.restaurantDetails!. //
                                                      data!.marketDetails!.averageRating}",
                                                  // text: "4.5",
                                                  fontColor:
                                                      const Color(0xff9A9A9A),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 8.sp,
                                                ),
                                                SizedBox(width: 2.w),
                                                Container(
                                                  width: 2.w,
                                                  height: 2.h,
                                                  decoration:
                                                      const BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: Color(0xffC4C4C4),
                                                  ),
                                                ),
                                                SizedBox(width: 2.w),
                                                CustomText(
                                                  text: "${homeController.restaurantDetails!. //
                                                      data!.marketDetails!.totalReviews} Reviews",
                                                  // text: "415 Reviews",
                                                  fontColor:
                                                      const Color(0xff9A9A9A),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 8.sp,
                                                ),
                                                const Icon(
                                                  Icons
                                                      .keyboard_arrow_down_sharp,
                                                  size: 10,
                                                  color: Color(0xff9098B1),
                                                ),
                                                SizedBox(width: 12.w),
                                                const Icon(
                                                  Icons
                                                      .delivery_dining_outlined,
                                                  size: 8,
                                                  color: Color(0xff9098B1),
                                                ),
                                                CustomText(
                                                  text: "${homeController.restaurantDetails!. //
                                                      data!.marketDetails!.distance} km",
                                                  // text: "25mins",
                                                  fontColor:
                                                      const Color(0xff9A9A9A),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 8.sp,
                                                ),
                                                SizedBox(width: 12.w),
                                                const Icon(
                                                  Icons
                                                      .delivery_dining_outlined,
                                                  size: 8,
                                                  color: Color(0xff9098B1),
                                                ),
                                                CustomText(
                                                  // text: "${homeController.restaurantDetails!. //
                                                  //     data!.marketDetails!.averageRating}",
                                                  text: "\$5.00",
                                                  fontColor:
                                                      const Color(0xff9A9A9A),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 8.sp,
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 30, right: 30).r,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  CustomText(
                                    text: "Services",
                                    fontColor: const Color(0xff444444),
                                    fontWeight: FontWeight.w500,
                                    fontSize: 20.sp,
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 20.h),
                            SizedBox(
                              height: 37.h,
                              child: ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: homeController.restaurantDetails!
                                      .data!.categoryList!.length,
                                  // jobsTypes.length,
                                  itemBuilder: (context, index) {
                                    Category? category = homeController
                                        .restaurantDetails!
                                        .data!
                                        .categoryList![index];
                                    return Container(
                                      padding: EdgeInsets.only(left: 8.0.w),
                                      child: GestureDetector(
                                        onTap: () {
                                          currentSelected = index;
                                          homeController.currentCategoryId =
                                              category.id.toString();
                                          setState(() {});
                                        },
                                        child: SizedBox(
                                          height: 37.h,
                                          width: 81.w,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: currentSelected == index
                                                  ? const Color(0xff5D3EBF)
                                                  : const Color(0xffFFFFFF),
                                              borderRadius:
                                                  BorderRadius.circular(50.0.r),
                                              border: Border.all(
                                                width: 1,
                                                color: const Color(0xffE5E5E5),
                                              ),
                                              boxShadow: const [
                                                BoxShadow(
                                                  offset: Offset(0, 0),
                                                  blurRadius: 5.0,
                                                  spreadRadius: 0.0,
                                                  color: Color(0xffE5E5E5),
                                                ),
                                              ],
                                            ),
                                            child: Center(
                                              child: Text(
                                                "${category.name}",
                                                // jobsTypes[index],
                                                style: TextStyle(
                                                  fontSize: 12.sp,
                                                  fontWeight: FontWeight.w500,
                                                  fontFamily: "DMSans",
                                                  color: currentSelected ==
                                                          index
                                                      ? const Color(0xffFFFFFF)
                                                      : const Color(0xff444444),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  }),
                            ),
                            SizedBox(height: 25.h),
                            // screens[currentSelected],
                            // ServiceProducts(),
                            // Burgers(),
                            Wrap(
                              children: homeController
                                  .restaurantDetails!.data!.productList!.data!
                                  .map((product) {
                                return homeController.currentCategoryId !=
                                        product.categoryId
                                    ? Container()
                                    : InkWell(
                                        onTap: () {
                                          // await takePhoto(ImageSource.gallery);
                                          homeController.currentProductId =
                                              product.id;
                                          Get.to(ProductDetails());
                                        },
                                        child: Card(
                                          color: const Color(0xffffffff),
                                          child: Container(
                                            height: 111.h,
                                            // width: 315.w,
                                            decoration: BoxDecoration(
                                              color: const Color(0xffffffff),
                                              borderRadius:
                                                  BorderRadius.circular(8.r),
                                              boxShadow: const [
                                                BoxShadow(
                                                  offset: Offset(0, 0),
                                                  blurRadius: 5.0,
                                                  color: Color(0xffE5E5E5),
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Row(
                                                  children: [
                                                    // Image.asset(burgerListModel[index].imageName,
                                                    SizedBox(
                                                      height: 111.h,
                                                      width: 92.w,
                                                      child: Image.network(
                                                        product.image!,
                                                        height: 111.h,
                                                        width: 92.w,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        SizedBox(
                                                          width: Get.width -
                                                              100.w, //* 0.68,
                                                          child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Padding(
                                                                padding: const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            10)
                                                                    .r,
                                                                child:
                                                                    CustomText(
                                                                  text:
                                                                      "${product.name}",
                                                                  // text: "Chef’s Burger",
                                                                  fontColor:
                                                                      const Color(
                                                                          0xff000000),
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontSize:
                                                                      14.sp,
                                                                ),
                                                              ),
                                                              // SizedBox(width: 60.h),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .all(
                                                                        8.0),
                                                                child: InkWell(
                                                                  onTap:
                                                                      () async {
                                                                    await makeItFavorite(
                                                                        context,
                                                                        product);
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    height:
                                                                        30.h,
                                                                    width: 30.w,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: const Color(
                                                                          0xffFEBD00),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              3.r),
                                                                    ),
                                                                    child:
                                                                        const Icon(
                                                                      Icons
                                                                          .favorite_border,
                                                                      size: 14,
                                                                      color: Colors
                                                                          .white,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                          .only(
                                                                      left: 12)
                                                                  .r,
                                                          child: SizedBox(
                                                            height: 30.h,
                                                            width: Get.width -
                                                                120.w,
                                                            // width: Get.width * 0.6,
                                                            child: CustomText(
                                                              text:
                                                                  "${product.description}",
                                                              // text: burgerListModel[index].text,
                                                              fontColor:
                                                                  const Color(
                                                                      0xff868686),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              fontSize: 11.sp,
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(height: 8.h),
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          children: [
                                                            Padding(
                                                              padding: const EdgeInsets
                                                                          .only(
                                                                      left: 12)
                                                                  .r,
                                                              child: CustomText(
                                                                text:
                                                                    "\$${product.price}",
                                                                // text: burgerListModel[index].text1,
                                                                fontColor:
                                                                    const Color(
                                                                        0xffEC2547),
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                fontSize: 14.sp,
                                                              ),
                                                            ),
                                                            SizedBox(
                                                                width: 96.w),
                                                            Container(
                                                              height: 17.h,
                                                              width: 31.w,
                                                              decoration: BoxDecoration(
                                                                  color: const Color(
                                                                      0xffF4F4F4),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              3.r)),
                                                              child: Center(
                                                                child:
                                                                    IconButton(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                  icon:
                                                                      const Icon(
                                                                    Icons.add,
                                                                    size: 10,
                                                                    color: Color(
                                                                        0xffEC2547),
                                                                  ),
                                                                  onPressed:
                                                                      () {
                                                                    Get.to(
                                                                        const ProductDetails());
                                                                  },
                                                                ),
                                                              ),
                                                            )
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                              }).toList(),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
        );
      },
    );
  }
}
