import 'package:aifood/View/Rating&Reviews/ratting_reviews_screen.dart';
import 'package:aifood/View/Track%20Order/track_order_screen.dart';
import 'package:aifood/controllers/cart_controller.dart';
import 'package:aifood/controllers/orders_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../Custom Widget/button.dart';
import '../Custom Widget/custom_text.dart';
import '../My Cart/mycart_screen.dart';
import '../Reviews/reviews_screen.dart';

class OrderDetails extends StatefulWidget {
  const OrderDetails({Key? key}) : super(key: key);

  @override
  State<OrderDetails> createState() => _OrderDetailsState();
}

class _OrderDetailsState extends State<OrderDetails> {
  // var ordersController = Get.put(OrdersController());
  CartController cartController = Get.put(CartController());
  OrdersController ordersController = Get.find();
  @override
  initState() {
    ordersController.getOrderDetail();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetX<OrdersController>(
      builder: (controller) {
        return Scaffold(
          body: SafeArea(
            child: controller.odLoading.value
                ? const Center(child: CircularProgressIndicator())
                : SingleChildScrollView(
                    child: Container(
                      padding: const EdgeInsets.only(top: 20).r,
                      child: Column(
                        children: [
                          Container(
                            child: Row(
                              children: [
                                IconButton(
                                  icon: const Icon(
                                    Icons.arrow_back_ios_new,
                                    color: Color(0xff444444),
                                  ),
                                  iconSize: 13,
                                  onPressed: () {
                                    // Get.off(const SigninScreen());
                                    Get.back();
                                  },
                                ),
                                CustomText(
                                  text: "Order Details",
                                  fontColor: const Color(0xff444444),
                                  fontWeight: FontWeight.w700,
                                  fontSize: 20.sp,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 40.h),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 30, right: 30).r,
                            child: Container(
                              child: Column(
                                children: [
                                  Container(
                                      child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Order number:",
                                        fontColor: const Color(0xff868686),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16.sp,
                                      ),
                                      CustomText(
                                        text:
                                            "${controller.orderDetail!.orderData!.orderNo}",
                                        // text: "123456789",
                                        fontColor: const Color(0xff222222),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16.sp,
                                      ),
                                    ],
                                  )),
                                  SizedBox(height: 12.h),
                                  Container(
                                      child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Tracking number:",
                                        fontColor: const Color(0xff868686),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16.sp,
                                      ),
                                      CustomText(
                                        text:
                                            "${controller.orderDetail!.orderData!.trackingNo}",
                                        // text: "US123456789",
                                        fontColor: const Color(0xff222222),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16.sp,
                                      ),
                                    ],
                                  )),
                                  SizedBox(height: 12.h),
                                  Container(
                                      child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Status:",
                                        fontColor: const Color(0xff868686),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16.sp,
                                      ),
                                      CustomText(
                                        text:
                                            "${controller.orderDetail!.orderData!.status}",
                                        // text: "Delivered",
                                        fontColor: const Color(0xffFFBA49),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16.sp,
                                      ),
                                    ],
                                  )),
                                  SizedBox(height: 15.h),
                                  Container(
                                      child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Delivery Date:",
                                        fontColor: const Color(0xff868686),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16.sp,
                                      ),
                                      CustomText(
                                        text:
                                            "${controller.orderDetail!.orderData!.deliveryDate}",
                                        // text: "06-23-2021",
                                        fontColor: const Color(0xff222222),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16.sp,
                                      ),
                                    ],
                                  )),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 12.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 30, right: 30)
                                        .r,
                                child: Container(
                                  child: CustomText(
                                    text: "Items",
                                    fontColor: const Color(0xff444444),
                                    fontWeight: FontWeight.w700,
                                    fontSize: 18.sp,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 20.h),
                          cartController.cartDetails!.details!.isEmpty
                              ? Padding(
                                  padding: const EdgeInsets.only(bottom: 8.0),
                                  child: CustomText(
                                    text: "No Item Found",
                                    fontColor: const Color(0xff444444),
                                    fontWeight: FontWeight.w500,
                                    fontSize: 15.sp,
                                  ),
                                )
                              : SizedBox(
                                  height: controller.orderDetail!.orderData!
                                              .items!.length >
                                          1
                                      ? 170.h
                                      : 100.h,
                                  child: ListView(
                                      children: controller
                                          .orderDetail!.orderData!.items!
                                          .map(
                                    (item) {
                                      return Padding(
                                        padding: const EdgeInsets.all(4.0),
                                        child: Container(
                                          height: 94.h,
                                          width: 315.w,
                                          decoration: BoxDecoration(
                                            color: const Color(0xffFFFFFF),
                                            borderRadius:
                                                BorderRadius.circular(8.r),
                                            boxShadow: const [
                                              BoxShadow(
                                                offset: Offset(0, 0),
                                                blurRadius: 5.0,
                                                color: Color(0xffE5E5E5),
                                              ),
                                            ],
                                          ),
                                          child: Column(
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  SizedBox(
                                                    height: 94.h,
                                                    width: 99.w,
                                                    // child: Image.asset("assets/images/OrderDetail.png",
                                                    child: Image.network(
                                                      "${item.productImage}",
                                                      height: 94.h,
                                                      width: 99.w,
                                                      fit: BoxFit.fill,
                                                    ),
                                                  ),
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                            .all(
                                                                        10.0)
                                                                    .r,
                                                            child: CustomText(
                                                              text:
                                                                  "${item.productName}",
                                                              // text: "Chef’s Burger",
                                                              fontColor:
                                                                  const Color(
                                                                      0xff444444),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              fontSize: 14.sp,
                                                            ),
                                                          ),
                                                          SizedBox(width: 38.w),
                                                          Container(
                                                            padding:
                                                                const EdgeInsets
                                                                            .only(
                                                                        right:
                                                                            15)
                                                                    .r,
                                                            child: CustomText(
                                                              text:
                                                                  "${item.productName}",
                                                              // text: "06-23-2021",
                                                              fontColor:
                                                                  const Color(
                                                                      0xffC0C0C0),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontSize: 10.sp,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                        .only(
                                                                    left: 10,
                                                                    right: 10)
                                                                .r,
                                                        child: Row(
                                                          children: [
                                                            RichText(
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              text: TextSpan(
                                                                text:
                                                                    "Quantity:",
                                                                style:
                                                                    TextStyle(
                                                                  color: const Color(
                                                                      0xff9B9B9B),
                                                                  fontSize:
                                                                      12.sp,
                                                                  fontFamily:
                                                                      'DMSans',
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                ),
                                                                children: <
                                                                    TextSpan>[
                                                                  TextSpan(
                                                                    text:
                                                                        " ${item.quantity}",
                                                                    // text: " 2",
                                                                    style:
                                                                        TextStyle(
                                                                      color: const Color(
                                                                          0xff444444),
                                                                      fontSize:
                                                                          12.sp,
                                                                      fontFamily:
                                                                          'DMSans',
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w400,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            SizedBox(
                                                                width: 10.w),
                                                            RichText(
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              text: TextSpan(
                                                                text: "Size: ",
                                                                style:
                                                                    TextStyle(
                                                                  color: const Color(
                                                                      0xff9B9B9B),
                                                                  fontSize:
                                                                      12.sp,
                                                                  fontFamily:
                                                                      'DMSans',
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                ),
                                                                children: <
                                                                    TextSpan>[
                                                                  TextSpan(
                                                                    text:
                                                                        "${item.size}",
                                                                    // text: "Large",
                                                                    style:
                                                                        TextStyle(
                                                                      color: const Color(
                                                                          0xff444444),
                                                                      fontSize:
                                                                          12.sp,
                                                                      fontFamily:
                                                                          'DMSans',
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w400,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                        .only(
                                                                    left: 10,
                                                                    right: 10,
                                                                    top: 15)
                                                                .r,
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            RichText(
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              text: TextSpan(
                                                                text: "Extras:",
                                                                style:
                                                                    TextStyle(
                                                                  color: const Color(
                                                                      0xff9B9B9B),
                                                                  fontSize:
                                                                      12.sp,
                                                                  fontFamily:
                                                                      'DMSans',
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                ),
                                                                children: <
                                                                    TextSpan>[
                                                                  TextSpan(
                                                                    text:
                                                                        "${item.totalExtrasQuantity}",
                                                                    // text: " 0",
                                                                    style:
                                                                        TextStyle(
                                                                      color: const Color(
                                                                          0xff444444),
                                                                      fontSize:
                                                                          12.sp,
                                                                      fontFamily:
                                                                          'DMSans',
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w400,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            SizedBox(
                                                                width: 100.w),
                                                            CustomText(
                                                              text:
                                                                  "\$${item.price}",
                                                              // text: "\$45.99",
                                                              fontColor:
                                                                  const Color(
                                                                      0xff000000),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              fontSize: 14.sp,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ).toList()),
                                ),
                          // Container(
                          //   height: 94.h,
                          //   width: 315.w,
                          //   decoration: BoxDecoration(
                          //     color: const Color(0xffFFFFFF),
                          //     borderRadius: BorderRadius.circular(8.r),
                          //     boxShadow: const [
                          //       BoxShadow(
                          //         offset: Offset(0, 0),
                          //         blurRadius: 5.0,
                          //         color: Color(0xffE5E5E5),
                          //       ),
                          //     ],
                          //   ),
                          //   child: Column(
                          //     children: [
                          //       Row(
                          //         mainAxisAlignment:
                          //             MainAxisAlignment.spaceBetween,
                          //         children: [
                          //           Image.asset(
                          //             "assets/images/OrderDetail.png",
                          //             height: 94.h,
                          //             width: 99.w,
                          //             fit: BoxFit.fill,
                          //           ),
                          //           Column(
                          //             crossAxisAlignment:
                          //                 CrossAxisAlignment.start,
                          //             children: [
                          //               Row(
                          //                 mainAxisAlignment:
                          //                     MainAxisAlignment.spaceBetween,
                          //                 children: [
                          //                   Padding(
                          //                     padding:
                          //                         const EdgeInsets.all(10.0).r,
                          //                     child: CustomText(
                          //                       text: "Chef’s Burger",
                          //                       fontColor:
                          //                           const Color(0xff444444),
                          //                       fontWeight: FontWeight.w700,
                          //                       fontSize: 14.sp,
                          //                     ),
                          //                   ),
                          //                   SizedBox(
                          //                     width: 38.w,
                          //                   ),
                          //                   Container(
                          //                     padding: const EdgeInsets.only(
                          //                             right: 15)
                          //                         .r,
                          //                     child: CustomText(
                          //                       text: "06-23-2021",
                          //                       fontColor:
                          //                           const Color(0xffC0C0C0),
                          //                       fontWeight: FontWeight.w400,
                          //                       fontSize: 10.sp,
                          //                     ),
                          //                   ),
                          //                 ],
                          //               ),
                          //               Padding(
                          //                 padding: const EdgeInsets.only(
                          //                         left: 10, right: 10)
                          //                     .r,
                          //                 child: Row(
                          //                   children: [
                          //                     RichText(
                          //                       textAlign: TextAlign.center,
                          //                       text: TextSpan(
                          //                         text: "Quantity:",
                          //                         style: TextStyle(
                          //                           color:
                          //                               const Color(0xff9B9B9B),
                          //                           fontSize: 12.sp,
                          //                           fontFamily: 'DMSans',
                          //                           fontWeight: FontWeight.w400,
                          //                         ),
                          //                         children: <TextSpan>[
                          //                           TextSpan(
                          //                             text: " 2",
                          //                             style: TextStyle(
                          //                               color: const Color(
                          //                                   0xff444444),
                          //                               fontSize: 12.sp,
                          //                               fontFamily: 'DMSans',
                          //                               fontWeight:
                          //                                   FontWeight.w400,
                          //                             ),
                          //                           ),
                          //                         ],
                          //                       ),
                          //                     ),
                          //                     SizedBox(width: 10.w),
                          //                     RichText(
                          //                       textAlign: TextAlign.center,
                          //                       text: TextSpan(
                          //                         text: "Size: ",
                          //                         style: TextStyle(
                          //                           color:
                          //                               const Color(0xff9B9B9B),
                          //                           fontSize: 12.sp,
                          //                           fontFamily: 'DMSans',
                          //                           fontWeight: FontWeight.w400,
                          //                         ),
                          //                         children: <TextSpan>[
                          //                           TextSpan(
                          //                             text: "Large",
                          //                             style: TextStyle(
                          //                               color: const Color(
                          //                                   0xff444444),
                          //                               fontSize: 12.sp,
                          //                               fontFamily: 'DMSans',
                          //                               fontWeight:
                          //                                   FontWeight.w400,
                          //                             ),
                          //                           ),
                          //                         ],
                          //                       ),
                          //                     ),
                          //                   ],
                          //                 ),
                          //               ),
                          //               Padding(
                          //                 padding: const EdgeInsets.only(
                          //                         left: 10, right: 10, top: 15)
                          //                     .r,
                          //                 child: Row(
                          //                   mainAxisAlignment:
                          //                       MainAxisAlignment.spaceBetween,
                          //                   children: [
                          //                     RichText(
                          //                       textAlign: TextAlign.center,
                          //                       text: TextSpan(
                          //                         text: "Extras:",
                          //                         style: TextStyle(
                          //                           color:
                          //                               const Color(0xff9B9B9B),
                          //                           fontSize: 12.sp,
                          //                           fontFamily: 'DMSans',
                          //                           fontWeight: FontWeight.w400,
                          //                         ),
                          //                         children: <TextSpan>[
                          //                           TextSpan(
                          //                             text: " 0",
                          //                             style: TextStyle(
                          //                               color: const Color(
                          //                                   0xff444444),
                          //                               fontSize: 12.sp,
                          //                               fontFamily: 'DMSans',
                          //                               fontWeight:
                          //                                   FontWeight.w400,
                          //                             ),
                          //                           ),
                          //                         ],
                          //                       ),
                          //                     ),
                          //                     SizedBox(
                          //                       width: 100.w,
                          //                     ),
                          //                     CustomText(
                          //                       text: "\$45.99",
                          //                       fontColor:
                          //                           const Color(0xff000000),
                          //                       fontWeight: FontWeight.w700,
                          //                       fontSize: 14.sp,
                          //                     ),
                          //                   ],
                          //                 ),
                          //               ),
                          //             ],
                          //           ),
                          //         ],
                          //       ),
                          //     ],
                          //   ),
                          // ),

                          SizedBox(height: 20.h),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(left: 30, right: 30).r,
                              child: Container(
                                child: CustomText(
                                  text: "Order information",
                                  fontColor: const Color(0xff444444),
                                  fontWeight: FontWeight.w700,
                                  fontSize: 18.sp,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 20.h),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 30, right: 30).r,
                            child: Container(
                              child: Column(
                                children: [
                                  Container(
                                      child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Shipping address:",
                                        fontColor: const Color(0xff868686),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16.sp,
                                      ),
                                      CustomText(
                                        text:
                                            "${controller.orderDetail!.orderData!.shippingAddress!.first.address}",
                                        // text: "3 Newbridge Court,CA 91709,\n United States",
                                        fontColor: const Color(0xff222222),
                                        fontWeight: FontWeight.w500,
                                        fontSize: 12.sp,
                                      ),
                                    ],
                                  )),
                                  SizedBox(height: 12.h),
                                  Container(
                                      child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Payment method:",
                                        fontColor: const Color(0xff868686),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16.sp,
                                      ),
                                      // SizedBox(width: 22.w),
                                      // Image.asset(
                                      //   "assets/images/MasteCard.png",
                                      //   height: 25.h,
                                      //   width: 32,
                                      //   fit: BoxFit.fill,
                                      // ),
                                      // SizedBox(width: 8.w),
                                      CustomText(
                                        text:
                                            "${controller.orderDetail!.orderData!.paymentMethod}",
                                        // text: "**** **** **** "
                                        //     "${controller.orderDetail!.orderData!.paymentCardNumberLastfourdigits}",
                                        // text: "**** **** **** 3947",
                                        fontColor: const Color(0xff222222),
                                        fontWeight: FontWeight.w500,
                                        fontSize: 12.sp,
                                      ),
                                    ],
                                  )),
                                  SizedBox(height: 12.h),
                                  Container(
                                      child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Resturant:",
                                        fontColor: const Color(0xff868686),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16.sp,
                                      ),
                                      CustomText(
                                        text:
                                            "${controller.orderDetail!.orderData!.marketName}",
                                        // text: "Burger King",
                                        fontColor: const Color(0xff444444),
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16.sp,
                                      ),
                                    ],
                                  )),
                                  SizedBox(height: 12.h),
                                  Container(
                                      child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Discount::",
                                        fontColor: const Color(0xff868686),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16.sp,
                                      ),
                                      CustomText(
                                        text:
                                            "${controller.orderDetail!.orderData!.discount}",
                                        // text: "10%, Personal promo code",
                                        fontColor: const Color(0xff444444),
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16.sp,
                                      ),
                                    ],
                                  )),
                                  SizedBox(height: 12.h),
                                  Container(
                                      child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Total:",
                                        fontColor: const Color(0xff444444),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 18.sp,
                                      ),
                                      CustomText(
                                        text:
                                            "${controller.orderDetail!.orderData!.itemTotal}",
                                        // text: "\$40.00",
                                        fontColor: const Color(0xff444444),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 18.sp,
                                      ),
                                    ],
                                  )),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 40.h),
                          "${controller.orderDetail!.orderData!.status}" ==
                                  "Cancelled"
                              ? Container(
                                  padding:
                                      const EdgeInsets.only(left: 30, right: 30)
                                          .r,
                                  height: 45.h,
                                  width: double.infinity.w,
                                  // width: 142.w,
                                  child: MyCustomButton(
                                    onPressed: () {
                                      controller.customerId = controller
                                          .orderDetail!.orderData!.userId;
                                      Get.to(const RattingReviewsScreen());
                                      // Get.to(const ReviewsScreen());
                                    },
                                    height: 45.h,
                                    width: 142.w,
                                    // buttonColor: const Color(0xffEC2547),
                                    text: "Rate",
                                    textColor: const Color(0xffFFFFFF),
                                    fontSize: 14.sp,
                                  ),
                                )
                              : "${controller.orderDetail!.orderData!.status}" ==
                                      "Delivered"
                                  ? Container(
                                      padding: const EdgeInsets.only(
                                              left: 30, right: 30)
                                          .r,
                                      height: 45.h,
                                      width: double.infinity.w,
                                      // width: 142.w,
                                      child: MyCustomButton(
                                        onPressed: () {
                                          controller.customerId = controller
                                              .orderDetail!.orderData!.userId;
                                          Get.to(const RattingReviewsScreen());
                                          // Get.to(const ReviewsScreen());
                                        },
                                        height: 45.h,
                                        width: 142.w,
                                        // buttonColor: const Color(0xffEC2547),
                                        text: "Rate",
                                        textColor: const Color(0xffFFFFFF),
                                        fontSize: 14.sp,
                                      ),
                                    )
                                  : Container(
                                      padding: const EdgeInsets.only(
                                              left: 30, right: 30)
                                          .r,
                                      height: 45.h,
                                      width: double.infinity.w,
                                      child: MyCustomButton(
                                        onPressed: () {
                                          cartController.orderId = controller
                                              .orderDetail!.orderData!.id;
                                          Get.to(TrackOrderScreen());
                                        },
                                        height: 45.h,
                                        width: 142.w,
                                        // buttonColor: const Color(0xffEC2547),
                                        text: "Track Order",
                                        textColor: const Color(0xffFFFFFF),
                                        fontSize: 14.sp,
                                      ),
                                    ),
                          // Container(
                          //   padding:
                          //       const EdgeInsets.only(left: 30, right: 30).r,
                          //   child: Row(
                          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          //     children: [
                          //       Container(
                          //         height: 45.h,
                          //         width: 142.w,
                          //         child: MyCustomButton(
                          //           onPressed: () {
                          //             Get.to(const MycartScreen());
                          //           },
                          //           height: 45.h,
                          //           width: 142.w,
                          //           buttonColor: const Color(0xffEC2547),
                          //           text: "Reorder",
                          //           textColor: const Color(0xffFFFFFF),
                          //           fontSize: 14.sp,
                          //         ),
                          //       ),
                          //       Container(
                          //         height: 45.h,
                          //         width: 142.w,
                          //         child: MyCustomButton(
                          //           onPressed: () {
                          //             Get.to(const ReviewsScreen());
                          //           },
                          //           height: 45.h,
                          //           width: 142.w,
                          //           buttonColor: const Color(0xffEC2547),
                          //           text: "Rate",
                          //           textColor: const Color(0xffFFFFFF),
                          //           fontSize: 14.sp,
                          //         ),
                          //       ),
                          //     ],
                          //   ),
                          // ),
                          SizedBox(height: 40.h),
                        ],
                      ),
                    ),
                  ),
          ),
        );
      },
    );
  }
}
