import 'package:aifood/View/Login/login_screen.dart';
import 'package:aifood/View/Product%20Details/product_details.dart';
import 'package:aifood/controllers/favorites_controller.dart';
import 'package:aifood/controllers/home_controller.dart';
import 'package:aifood/models/favorite_products.dart';
import 'package:aifood/user_prefs/user_prefs.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../Custom Widget/custom_text.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({Key? key}) : super(key: key);

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  List<String> images = ["assets/images/shop.png"];
  int? selectedIndex = 0;
  int checkedIndex = 0;
  List cardNames = [
    'Sports',
    'Wild Life',
    'Night',
    'LandSpace',
  ];
  var favoritesController = Get.put(FavoritesController());
  var homeController = Get.put(HomeController());

  // List cardNames = [
  //   'Sports',
  //   'Wild Life',
  //   'Night',
  //   'LandSpace',
  // ];
   nextScreen() async {
     bool? isLogin = await UserPreferences.getLoginCheck() ?? false;
     if(isLogin==false)
     {
       Get.to(LoginScreen());
     }
     else {
       favoritesController.getFavoriteList();
     }
   }
  @override
  initState()  {
    nextScreen();
    super.initState();
    // favoritesController.getFavoriteProducts();
  }

  @override
  Widget build(BuildContext context) {
    return GetX<FavoritesController>(
      builder: (controller) {
        return controller.loading.value
            ? const CircularProgressIndicator()
            : Scaffold(
                backgroundColor: Colors.white,
                body: SafeArea(
                  child: SingleChildScrollView(
                    child: Container(
                      padding: const EdgeInsets.only(
                        left: 30,
                        right: 30,
                        top: 50,
                        bottom: 20,
                      ).r,
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(
                                text: "Explore",
                                fontColor: const Color(0xff444444),
                                fontWeight: FontWeight.w500,
                                fontSize: 24.sp,
                              ),
                              SizedBox(width: 50.w),
                              Container(
                                height: 30.h,
                                width: 30.w,
                                decoration: BoxDecoration(
                                  color: const Color(0xffEC2547),
                                  borderRadius: BorderRadius.circular(3.r),
                                ),
                                child: const Icon(
                                  Icons.notifications_none_outlined,
                                  size: 14,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 20.h),
                          Row(children: [
                            Flexible(
                              flex: 1,
                              child: Container(
                                height: 45.h,
                                width: 260.w,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8.0.r),
                                  boxShadow: const [
                                    BoxShadow(
                                      offset: Offset(0, 0),
                                      blurRadius: 5.0,
                                      color: Color(0xffE5E5E5),
                                    ),
                                  ],
                                ),
                                child: TextField(
                                  cursorColor: Colors.grey,
                                  decoration: InputDecoration(
                                    fillColor: Colors.white,
                                    filled: true,
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(10.r),
                                        borderSide: BorderSide.none),
                                    hintText: 'Search',
                                    hintStyle: TextStyle(
                                        color: const Color(0xffC0C0C0),
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: ''),
                                    prefixIcon: const Icon(
                                      Icons.search,
                                      size: 20,
                                      color: Color(0xffEC2547),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 10.w),
                            Container(
                              height: 45.h,
                              width: 45.w,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(8.0.r),
                                boxShadow: const [
                                  BoxShadow(
                                    offset: Offset(0, 5),
                                    blurRadius: 10.0,
                                    color: Color(0xffE5E5E5),
                                  ),
                                ],
                              ),
                              child: Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: const [
                                    Icon(
                                      Icons.filter_alt_outlined,
                                      color: Colors.red,
                                    ),
                                    // SizedBox(
                                    //   height: 24.5.h,
                                    //   width: 24.5.w,
                                    //   child: Image.asset(
                                    //     "assets/images/ic_filter.png",
                                    //     height: 24.5.h,
                                    //     width: 24.5.w,
                                    //   ),
                                    // ),
                                  ],
                                ),
                              ),
                            ),
                          ]),
                          SizedBox(height: 20.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Services",
                                fontColor: const Color(0xff444444),
                                fontWeight: FontWeight.w500,
                                fontSize: 20.sp,
                              ),
                            ],
                          ),
                          SizedBox(height: 20.h),
                          // Container(
                          //   height: 220.h,
                          //   child: GridView.builder(
                          //     physics: const ScrollPhysics(),
                          //     controller: ScrollController(keepScrollOffset: false),
                          //     shrinkWrap: true,
                          //     itemCount: 12,
                          //     gridDelegate:
                          //         const SliverGridDelegateWithFixedCrossAxisCount(
                          //       crossAxisCount: 4,
                          //       crossAxisSpacing: 5.0,
                          //       mainAxisSpacing: 5.0,
                          //     ),
                          //     itemBuilder: (BuildContext context, int index) {
                          //       return GestureDetector(
                          //         child: Card(
                          //           color: selectedIndex == index
                          //               ? Color(0xffEC2547)
                          //               : Color(0xfffFFFFFF),
                          //           child: Container(
                          //             height: 70.h,
                          //             width: 70.w,
                          //             padding: const EdgeInsets.all(5.0).r,
                          //             decoration: BoxDecoration(
                          //               color: selectedIndex == index
                          //                   ? Color(0xffEC2547)
                          //                   : Color(0xfffFFFFFF),
                          //               borderRadius: BorderRadius.circular(5.r),
                          //               boxShadow: const [
                          //                 BoxShadow(
                          //                   color: Color(0xffE5E5E5),
                          //                   spreadRadius: 0,
                          //                   blurRadius: 5,
                          //                   offset: Offset(0, 0),
                          //                 ),
                          //               ],
                          //             ),
                          //             child: Padding(
                          //               padding: const EdgeInsets.only(top: 5).r,
                          //               child: Column(
                          //                 children: [
                          //                   Image.asset(
                          //                     "assets/images/fashion.png",
                          //                     height: 21.h,
                          //                     width: 21.w,
                          //                     color: selectedIndex == index
                          //                         ? Color(0xfffFFFFFF)
                          //                         : Color.fromRGBO(68, 68, 68, 0.8),
                          //                   ),
                          //                   SizedBox(
                          //                     height: 9.h,
                          //                   ),
                          //                   CustomText(
                          //                     text: "Fashion",
                          //                     fontColor: selectedIndex == index
                          //                         ? Colors.white
                          //                         : Color(0xff444444).withOpacity(0.8),
                          //                     fontWeight: FontWeight.w500,
                          //                     fontSize: 11.sp,
                          //                   ),
                          //                 ],
                          //               ),
                          //             ),
                          //           ),
                          //         ),
                          //         onTap: () {
                          //           setState(() {
                          //             selectedIndex = index;
                          //           });
                          //         },
                          //       );
                          //     },
                          //   ),
                          // ),
                          SizedBox(height: 20.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Popular",
                                fontColor: const Color(0xff444444),
                                fontWeight: FontWeight.w500,
                                fontSize: 20.sp,
                              ),
                            ],
                          ),
                          SizedBox(height: 20.h),
                          Container(
                            // padding: const EdgeInsets.only(left: 15),
                            height: 170.h,
                            child: ListView.builder(
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              itemCount:
                                  favoritesController.favoriteProducts!.length,
                              // .favoriteProducts!.length, // 10,
                              itemBuilder: (BuildContext context, int index) {
                                FavoriteProduct product = favoritesController
                                    .favoriteProducts![index];
                                return InkWell(
                                  onTap: () {
                                    homeController.currentProductId =
                                        product.id.toString();
                                    setState(() {});
                                    Get.to(const ProductDetails());
                                  },
                                  child: Card(
                                    child: Container(
                                      height: 160.h,
                                      width: 230.w,
                                      padding: const EdgeInsets.all(8.0).r,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(5.r),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Color(0xffE5E5E5),
                                            spreadRadius: 0,
                                            blurRadius: 5,
                                            offset: Offset(0, 0),
                                          ),
                                        ],
                                      ),
                                      child: Column(
                                        children: [
                                          SizedBox(
                                            height: 110.h,
                                            width: 258.w,
                                            // child: Image.asset("assets/images/Eggs Benedict Burger.png"),
                                            child: Image.network(
                                              "${product.image}",
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                          SizedBox(height: 8.h),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              CustomText(
                                                text: "${product.name}",
                                                // text: "Eggs Benedict Burger",
                                                fontColor:
                                                    const Color(0xff444444),
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12.sp,
                                              ),
                                              CustomText(
                                                text: "${product.price}",
                                                // text: "\$80.00",
                                                fontColor:
                                                    const Color(0xff444444),
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12.sp,
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 2.h),
                                          Row(
                                            children: [
                                              CustomText(
                                                text: "${product.marketName}",
                                                // text: "Asian",
                                                fontColor:
                                                    const Color(0xffC0C0C0),
                                                fontWeight: FontWeight.w400,
                                                fontSize: 8.sp,
                                              ),
                                              // SizedBox(width: 2.w),
                                              // Container(
                                              //   width: 2.w,
                                              //   height: 2.h,
                                              //   decoration: const BoxDecoration(
                                              //     shape: BoxShape.circle,
                                              //     color: Color(0xffC0C0C0),
                                              //   ),
                                              // ),
                                              // SizedBox(width: 2.w),
                                              // CustomText(
                                              //   text: "Fast food",
                                              //   fontColor:
                                              //       const Color(0xffC0C0C0),
                                              //   fontWeight: FontWeight.w400,
                                              //   fontSize: 8.sp,
                                              // ),
                                              // SizedBox(width: 2.w),
                                              // Container(
                                              //   width: 2.w,
                                              //   height: 2.h,
                                              //   decoration: const BoxDecoration(
                                              //     shape: BoxShape.circle,
                                              //     color: Color(0xffC0C0C0),
                                              //   ),
                                              // ),
                                              // SizedBox(width: 2.w),
                                              // CustomText(
                                              //   text: "Sushi",
                                              //   fontColor:
                                              //       const Color(0xffC0C0C0),
                                              //   fontWeight: FontWeight.w400,
                                              //   fontSize: 8.sp,
                                              // ),
                                              SizedBox(width: 5.w),
                                              const Icon(
                                                Icons.star,
                                                color: Color(0xffFFC107),
                                                size: 6,
                                              ),
                                              // SizedBox(width: 16.w),
                                              CustomText(
                                                text:
                                                    "${product.averageRating}",
                                                // text: "4.5",
                                                fontColor:
                                                    const Color(0xff9A9A9A),
                                                fontWeight: FontWeight.w400,
                                                fontSize: 8.sp,
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
      },
    );
  }
}
