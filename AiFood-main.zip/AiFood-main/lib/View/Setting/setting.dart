import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../Custom Widget/custom_text.dart';

class Setting extends StatefulWidget {
  const Setting({Key? key}) : super(key: key);

  @override
  State<Setting> createState() => _SettingState();
}

class _SettingState extends State<Setting> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.only(top: 50).r,
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.only(
                  left: 10,
                ).r,
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(
                        Icons.arrow_back_ios_new,
                        color: Color(0xff444444),
                      ),
                      iconSize: 16,
                      onPressed: () {
                        // Get.off(const SigninScreen());
                        Get.back();
                      },
                    ),
                    CustomText(
                      text: "Setting",
                      fontColor: Color(0xff444444),
                      fontWeight: FontWeight.w500,
                      fontSize: 20.sp,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 20.h,
              ),
              GestureDetector(
                onTap: () {},
                child: Container(
                  padding: const EdgeInsets.only(left: 15, right: 15).r,
                  height: 45.h,
                  width: 315.w,
                  decoration: BoxDecoration(
                    color: Color(0xfffFFFFFF),
                    borderRadius: BorderRadius.circular(8.r),
                    boxShadow: [
                      BoxShadow(
                        offset: Offset(0, 0),
                        blurRadius: 5.0,
                        color: Color(0xffE5E5E5),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        text: "Change Language",
                        fontColor: Color(0xff9098B1),
                        fontWeight: FontWeight.w400,
                        fontSize: 12.sp,
                      ),
                      Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 20,
                        color: Color(0xffC0C0C0),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 12.h,
              ),
              GestureDetector(
                onTap: () {},
                child: Container(
                  padding: const EdgeInsets.only(left: 15, right: 15).r,
                  height: 45.h,
                  width: 315.w,
                  decoration: BoxDecoration(
                    color: Color(0xfffFFFFFF),
                    borderRadius: BorderRadius.circular(8.r),
                    boxShadow: [
                      BoxShadow(
                        offset: Offset(0, 0),
                        blurRadius: 5.0,
                        color: Color(0xffE5E5E5),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        text: "Delete Accounts",
                        fontColor: Color(0xff9098B1),
                        fontWeight: FontWeight.w400,
                        fontSize: 12.sp,
                      ),
                      Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 20,
                        color: Color(0xffC0C0C0),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 12.h,
              ),
              GestureDetector(
                onTap: () {},
                child: Container(
                  padding: const EdgeInsets.only(left: 15, right: 15).r,
                  height: 45.h,
                  width: 315.w,
                  decoration: BoxDecoration(
                    color: Color(0xfffFFFFFF),
                    borderRadius: BorderRadius.circular(8.r),
                    boxShadow: [
                      BoxShadow(
                        offset: Offset(0, 0),
                        blurRadius: 5.0,
                        color: Color(0xffE5E5E5),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        text: "Logout",
                        fontColor: Color(0xff9098B1),
                        fontWeight: FontWeight.w400,
                        fontSize: 12.sp,
                      ),
                      Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 20,
                        color: Color(0xffC0C0C0),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
