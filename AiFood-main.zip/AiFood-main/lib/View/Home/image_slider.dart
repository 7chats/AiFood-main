import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ImageSlider extends StatefulWidget {
  final List<String>? bannerImages;

  const ImageSlider({Key? key, this.bannerImages}) : super(key: key);

  @override
  State<ImageSlider> createState() => _ImageSliderState();
}

class _ImageSliderState extends State<ImageSlider> {
  var _current = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CarouselSlider(
          options: CarouselOptions(
              disableCenter: false,
              aspectRatio: 16 / 8,
              initialPage: 0,
              viewportFraction: 0.8,
              enlargeCenterPage: true,
              autoPlay: true,
              reverse: false,
              height: 150.h,
              enableInfiniteScroll: true,
              autoPlayInterval: const Duration(seconds: 3),
              // autoPlayAnimationDuration:
              //     const Duration(milliseconds: 2200),
              pauseAutoPlayOnTouch: true,
              scrollDirection: Axis.horizontal,
              pageSnapping: true,
              onPageChanged: (index, val) {
                _current = index;
                setState(() {
                  print('current index$_current $index');
                });
              }),
          items: [
            for (int i = 0; i < (widget.bannerImages?.length ?? 0); i++)
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: CachedNetworkImage(
                  imageUrl: '${widget.bannerImages?[i]}',
                  fit: BoxFit.cover,
                ),
              ),
          ],
        ),
////////////////////////////Grey Dots
        Padding(
          padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: map<Widget>(widget.bannerImages!, (index, url) {
              return Container(
                width: _current == index ? 20.0 : 10,
                height: _current == index ? 8.0 : 10,
                margin:
                    const EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  // shape: BoxShape.circle,
                  color: _current == index
                      ? const Color(0xff4870C0)
                      : const Color(0xffD9D9D9),
                ),
              );
            }),
          ),
        ),
      ],
    );
  }

  List<T> map<T>(List list, Function handler) {
    List<T> result = [];
    for (var i = 0; i < list.length; i++) {
      result.add(handler(i, list[i]));
    }
    return result;
  }
}
