import 'package:aifood/View/Home/category_products.dart';
import 'package:aifood/View/Home/image_slider.dart';
import 'package:aifood/View/Product%20Details/product_details.dart';
import 'package:aifood/controllers/home_controller.dart';
import 'package:aifood/models/categories.dart';
import 'package:aifood/models/suggested_products.dart';
import 'package:aifood/theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../Custom Widget/custom_text.dart';
import '../Store Details/store_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int? selectedIndex;
  int checkedIndex = 0;
  var homeController = Get.put(HomeController());

  // List cardNames = [
  //   'Sports',
  //   'Wild Life',
  //   'Night',
  //   'LandSpace',
  // ];

  @override
  initState() {
    super.initState();
    homeController.getHomeData();
  }

  @override
  Widget build(BuildContext context) {
    return GetX<HomeController>(
      builder: (controller) {
        return homeController.loading.value
            ? const CircularProgressIndicator()
            : Scaffold(
                backgroundColor: Colors.white,
                body: SafeArea(
                  child: SingleChildScrollView(
                    child: Container(
                      padding:
                          const EdgeInsets.only(left: 30, right: 30, top: 50).r,
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    text:
                                        "Hi, ${homeController.userProfile?.userData?.name ??"Johan"}",
                                    // text: "Hi, Sophie",
                                    fontColor: const Color(0xff444444),
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16.sp,
                                  ),
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.location_on_outlined,
                                        size: 10,
                                        color: Color(0xff9098B1),
                                      ),
                                      // SizedBox(width: 3.w,),
                                      CustomText(
                                        text: '${homeController.address.value}',
                                        // text: "Majeedhee Magu Rd, Malé, Maldives",
                                        fontColor: const Color(0xff9098B1),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 10.sp,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              CircleAvatar(
                                backgroundImage: NetworkImage(
                                    "${homeController.userProfile?.userData?.profilePic??"https://aifood.citizensadgrace.com/public/images/icon.png"}"),
                                // AssetImage("assets/images/avatar.png"),
                              ),
                            ],
                          ),
                          SizedBox(height: 20.h),
                          Row(children: [
                            Flexible(
                              flex: 1,
                              child: Container(
                                height: 45.h,
                                width: double.maxFinite.w,
                                decoration: BoxDecoration(
                                  color: const Color(0xffFFFFFF),
                                  borderRadius: BorderRadius.circular(62.0.r),
                                  border: Border.all(
                                    width: 1,
                                    color: const Color(0xffE5E5E5),
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      offset: Offset(0, 0),
                                      blurRadius: 5.0,
                                      spreadRadius: 0.0,
                                      color: Color(0xffE5E5E5),
                                    ),
                                  ],
                                ),
                                child: TextField(
                                  cursorColor: Colors.grey,
                                  decoration: InputDecoration(
                                    fillColor: Colors.white,
                                    filled: true,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(62.r),
                                      borderSide: BorderSide.none,
                                    ),
                                    hintText: 'Search',
                                    hintStyle: TextStyle(
                                      color: const Color(0xffC0C0C0),
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: 'DMSans',
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.search,
                                      size: 25,
                                      color: Color(0xff5D3EBF),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 10.w),
                            Container(
                              height: 45.h,
                              width: 45.w,
                              decoration: BoxDecoration(
                                color: const Color(0xffFFFFFF),
                                borderRadius: BorderRadius.circular(56.0.r),
                                border: Border.all(
                                  width: 1,
                                  color: const Color(0xffE5E5E5),
                                ),
                                boxShadow: const [
                                  BoxShadow(
                                    offset: Offset(0, 0),
                                    blurRadius: 5.0,
                                    spreadRadius: 0.0,
                                    color: Color(0xffE5E5E5),
                                  ),
                                ],
                              ),
                              child: const ImageIcon(
                                AssetImage(
                                  "assets/images/Notificaton.png",
                                ),
                                color: Color(0xff5D3EBF),
                                size: 18,
                              ),
                            ),
                          ]),
                          SizedBox(height: 20.h),
                          ImageSlider(
                              bannerImages: homeController.banners!.banners),
                          // Image.asset(
                          //   "assets/images/HomeImage.png",
                          //   height: 180.h,
                          //   width: 315.w,
                          // ),
                          SizedBox(height: 20.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Categories",
                                fontColor: const Color(0xff444444),
                                fontWeight: FontWeight.w700,
                                fontSize: 20.sp,
                              ),
                            ],
                          ),
                          SizedBox(height: 20.h),
                          Container(
                            height: 45.h,
                            child: ListView.builder(
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              itemCount:
                                  homeController.categories!.categories!.length,
                              // servicesListModel.length,
                              itemBuilder: (BuildContext context, int index) {
                                Category category = homeController
                                    .categories!.categories![index];
                                return Container(
                                  padding: EdgeInsets.only(left: 10.0.w),
                                  child: GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        selectedIndex = index;
                                      });
                                      homeController.categoryId =
                                          category.id.toString();
                                      homeController.category = category;
                                      Get.to(CategoryProducts());
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.all(5.0),
                                      height: 45.h,
                                      // width: 110.w,
                                      decoration: BoxDecoration(
                                        color: selectedIndex == index
                                            ? const Color(0xff5D3EBF)
                                            : const Color(0xffF7F7F7),
                                        borderRadius:
                                            BorderRadius.circular(69.r),
                                        border: Border.all(
                                          width: 1,
                                          color: const Color(0xffE5E5E5),
                                        ),
                                        boxShadow: const [
                                          BoxShadow(
                                            offset: Offset(0, 0),
                                            blurRadius: 0.0,
                                            color: Color(0xffE5E5E5),
                                          ),
                                        ],
                                      ),
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(right: 8.0),
                                        child: Row(
                                          children: [
                                            // Image.asset(servicesListModel[1].imageName,
                                            // Image.network(
                                            //   category.media!.first.url!,
                                            //   height: 38.h,
                                            //   width: 38.w,
                                            // ),
                                            CircleAvatar(
                                              radius: 19.r,
                                              backgroundColor: AppTheme.appColor
                                                  .withOpacity(0.5),
                                              backgroundImage: NetworkImage(
                                                "${category.image ?? ""}",
                                              ),
                                            ),
                                            SizedBox(width: 5.h),
                                            CustomText(
                                              // text: servicesListModel[index].text,
                                              text: category.name,
                                              fontColor: selectedIndex == index
                                                  ? Colors.white
                                                  : const Color(0xff444444),
                                              fontWeight: FontWeight.w500,
                                              fontSize: 16.sp,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          SizedBox(height: 20.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Suggested",
                                fontColor: const Color(0xff444444),
                                fontWeight: FontWeight.w700,
                                fontSize: 20.sp,
                              ),
                            ],
                          ),
                          SizedBox(height: 20.h),
                          Container(
                            // padding: const EdgeInsets.only(left: 15),
                            height: 172.h,
                            child: ListView.builder(
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              itemCount: homeController
                                  .suggestedProducts!.products!.length, // 10,
                              itemBuilder: (BuildContext context, int index) {
                                Product? product = homeController
                                    .suggestedProducts!.products![index];
                                return GestureDetector(
                                  onTap: () {
                                    homeController.currentProductId =
                                        product.id.toString();
                                    setState(() {});
                                    Get.to(const ProductDetails());
                                  },
                                  child: Card(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20.r),
                                    ),
                                    child: Container(
                                      height: 162.h,
                                      width: 230.w,
                                      padding: const EdgeInsets.all(8.0).r,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(15.r),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Color(0xffE5E5E5),
                                            spreadRadius: 0,
                                            blurRadius: 5,
                                            offset: Offset(0, 0),
                                          ),
                                        ],
                                      ),
                                      child: Column(
                                        children: [
                                          // Image.asset("assets/images/Eggs Benedict Burger.png"),
                                          SizedBox(
                                            height: 110.h,
                                            width: 258.w,
                                            child: Image.network(
                                              "${product.image}",
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                          SizedBox(height: 8.h),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              CustomText(
                                                // text: "Eggs Benedict Burger",
                                                text: "${product.name}",
                                                fontColor:
                                                    const Color(0xff444444),
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12.sp,
                                              ),
                                              CustomText(
                                                // text: "\$80.00",
                                                text: "\$${product.price}",
                                                fontColor:
                                                    const Color(0xff444444),
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12.sp,
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 2.h),
                                          Row(
                                            children: [
                                              CustomText(
                                                // text: "Asian",
                                                text: "${product.marketName}",
                                                fontColor:
                                                    const Color(0xffC0C0C0),
                                                fontWeight: FontWeight.w400,
                                                fontSize: 8.sp,
                                              ),
                                              SizedBox(width: 2.w),
                                              Container(
                                                width: 2.w,
                                                height: 2.h,
                                                decoration: const BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: Color(0xffC0C0C0),
                                                ),
                                              ),
                                              // SizedBox(width: 2.w),
                                              // CustomText(
                                              //   text: "Fast food",
                                              //   fontColor:
                                              //       const Color(0xffC0C0C0),
                                              //   fontWeight: FontWeight.w400,
                                              //   fontSize: 8.sp,
                                              // ),
                                              // SizedBox(width: 2.w),
                                              // Container(
                                              //   width: 2.w,
                                              //   height: 2.h,
                                              //   decoration: const BoxDecoration(
                                              //     shape: BoxShape.circle,
                                              //     color: Color(0xffC0C0C0),
                                              //   ),
                                              // ),
                                              // SizedBox(width: 2.w),
                                              // CustomText(
                                              //   text: "Sushi",
                                              //   fontColor:
                                              //       const Color(0xffC0C0C0),
                                              //   fontWeight: FontWeight.w400,
                                              //   fontSize: 8.sp,
                                              // ),
                                              // SizedBox(width: 5.w),
                                              // const Icon(
                                              //   Icons.star,
                                              //   color: Color(0xffFFC107),
                                              //   size: 6,
                                              // ),
                                              // SizedBox(width: 2.w),
                                              // CustomText(
                                              //   // text: "4.5",
                                              //   text:
                                              //       "${product.averageRating}",
                                              //   fontColor:
                                              //       const Color(0xff9A9A9A),
                                              //   fontWeight: FontWeight.w400,
                                              //   fontSize: 8.sp,
                                              // ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          SizedBox(height: 20.h),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Restaurants Nearby",
                                fontColor: const Color(0xff444444),
                                fontWeight: FontWeight.w700,
                                fontSize: 20.sp,
                              ),
                            ],
                          ),
                          SizedBox(height: 20.h),
                          Container(
                            // padding: const EdgeInsets.only(left: 15),
                            height: 300.h, // 400.h,
                            width: 315.w,
                            child: ListView.builder(
                              shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              itemCount: homeController.nearByRestaurants!
                                  .restaurants!.length, // 10,
                              itemBuilder: (BuildContext context, int index) {
                                var restaurant = homeController
                                    .nearByRestaurants!.restaurants![index];
                                return GestureDetector(
                                  onTap: () {
                                    selectedIndex = index;
                                    setState(() {});
                                    homeController.currentRestaurantId =
                                        restaurant.id;
                                    Get.to(const StoreDetailScreen());
                                  },
                                  //  onTap: () {Get.to(SignUpScreen());},
                                  child: Card(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.r),
                                    ),
                                    child: Container(
                                      height: 74.h,
                                      width: 315.w,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(8.r),
                                        boxShadow: const [
                                          BoxShadow(
                                            offset: Offset(0, 0),
                                            blurRadius: 5.0,
                                            color: Color(0xffE5E5E5),
                                          ),
                                        ],
                                      ),
                                      child: ListTile(
                                        dense: false,
                                        contentPadding: const EdgeInsets.only(
                                          left: 8.0,
                                          right: 10.0,
                                          top: 4.0,
                                          bottom: 4.0,
                                        ).r,
                                        minVerticalPadding: 0,
                                        // minLeadingWidth: 0,
                                        // leading: Image.asset("assets/images/Burger King.png",
                                        leading: SizedBox(
                                          height: 58.h,
                                          width: 58.w,
                                          child: Image.network(
                                            "${restaurant.logo}",
                                            height: 58.h,
                                            width: 58.w,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                        title: Padding(
                                          padding:
                                              const EdgeInsets.only(top: 12),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              CustomText(
                                                text: "${restaurant.name}",
                                                // text: "Burger King",
                                                fontColor:
                                                    const Color(0xff444444),
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12.sp,
                                              ),
                                              Row(
                                                children: [
                                                  const Icon(
                                                    Icons.location_on_outlined,
                                                    size: 7,
                                                    color: Color(0xff9098B1),
                                                  ),
                                                  CustomText(
                                                    text:
                                                        "${restaurant.address}",
                                                    //  text: "Majeedhee Magu Rd, Malé, Maldives",
                                                    fontColor:
                                                        const Color(0xff9098B1),
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 6.sp,
                                                  ),
                                                ],
                                              ),
                                              SizedBox(height: 15.h),
                                              Row(
                                                children: [
                                                  const Icon(
                                                    Icons.star,
                                                    color: Color(0xffFFC107),
                                                    size: 7.0,
                                                  ),
                                                  // SizedBox(width: 16.w),
                                                  CustomText(
                                                    text:
                                                        "${restaurant.averageRating}",
                                                    // text: "4.5",
                                                    fontColor:
                                                        const Color(0xff9A9A9A),
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 8.sp,
                                                  ),
                                                  SizedBox(width: 8.w),
                                                  Image.asset(
                                                    "assets/images/Store Icon.png",
                                                    color:
                                                        const Color(0xff9A9A9A),
                                                    height: 7.h,
                                                    width: 7.w,
                                                    fit: BoxFit.fitWidth,
                                                  ),
                                                  SizedBox(width: 2.w),
                                                  CustomText(
                                                    text:
                                                        "${restaurant.distance} mins",
                                                    // text: "25mins",
                                                    fontColor:
                                                        const Color(0xff9A9A9A),
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 8.sp,
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        trailing: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 7.0),
                                              child: CustomText(
                                                text:
                                                    "${restaurant.openStatus}",
                                                // text: "OPEN",
                                                fontColor:
                                                    const Color(0xffEC2547),
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12.sp,
                                              ),
                                            ),
                                            // SizedBox(  height: 10.h ),
                                            Container(
                                              height: 17.h,
                                              width: 44.w,
                                              decoration: BoxDecoration(
                                                color: const Color(0xff5D3EBF),
                                                borderRadius:
                                                    BorderRadius.circular(2.r),
                                              ),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Image.asset(
                                                    "assets/images/Store Icon.png",
                                                    color: Colors.white,
                                                    height: 7.h,
                                                    width: 7.w,
                                                    fit: BoxFit.fitWidth,
                                                  ),
                                                  SizedBox(width: 2.w),
                                                  CustomText(
                                                    text:
                                                        "\$${restaurant.deliveryCharges}",
                                                    // text: "\$4.00",
                                                    fontColor: Colors.white,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 8.sp,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          // Container(
                          //   // padding: const EdgeInsets.only(left: 15),
                          //   height: 400.h,
                          //   width: 315.w,
                          //   child: ListView.builder(
                          //     shrinkWrap: true,
                          //     scrollDirection: Axis.vertical,
                          //     itemCount: 10,
                          //     itemBuilder: (BuildContext context, int index) {
                          //       return GestureDetector(
                          //         onTap: () {
                          //           setState(() {
                          //             Get.to(StoreDetailScreen());
                          //             selectedIndex = index;
                          //           });
                          //         },
                          //         //  onTap: () {Get.to(SignUpScreen());},
                          //         child: Card(
                          //           child: Container(
                          //             height: 74.h,
                          //             width: 315.w,
                          //             decoration: BoxDecoration(
                          //               color: Colors.blue,
                          //               borderRadius: BorderRadius.circular(5.r),
                          //               boxShadow: [
                          //                 BoxShadow(
                          //                   offset: Offset(0, 0),
                          //                   blurRadius: 5.0,
                          //                   color: Color(0xffE5E5E5),
                          //                 ),
                          //               ],
                          //             ),
                          //             child: Row(
                          //               children: [
                          //                 Image.asset(
                          //                   "assets/images/burger_king.png",
                          //                   height: 58.h,
                          //                   width: 58.w,
                          //                   fit: BoxFit.fill,
                          //                 ),
                          //                 Column(
                          //                   crossAxisAlignment: CrossAxisAlignment.start,
                          //                   // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          //                   children: [
                          //                     CustomText(
                          //                       text: "Burger King",
                          //                       fontColor: Color(0xff444444),
                          //                       fontWeight: FontWeight.w500,
                          //                       fontSize: 12.sp,
                          //                     ),
                          //                     Row(
                          //                       children: [
                          //                         Icon(
                          //                           Icons.location_on_outlined,
                          //                           size: 7,
                          //                           color: Color(0xff9098B1),
                          //                         ),
                          //                         CustomText(
                          //                           text:
                          //                               "Majeedhee Magu Rd, Malé, Maldives",
                          //                           fontColor: Color(0xff444444),
                          //                           fontWeight: FontWeight.w400,
                          //                           fontSize: 7.sp,
                          //                         ),
                          //                       ],
                          //                     ),
                          //                     Padding(
                          //                       padding: const EdgeInsets.only(
                          //                               left: 10, right: 10, top: 15)
                          //                           .r,
                          //                       child: Row(
                          //                         mainAxisAlignment:
                          //                             MainAxisAlignment.spaceBetween,
                          //                         children: [
                          //                           const Icon(
                          //                             Icons.star,
                          //                             color: const Color(0xffFFC107),
                          //                             size: 6,
                          //                           ),
                          //                           // SizedBox(width: 16.w),
                          //                           CustomText(
                          //                             text: "4.5",
                          //                             fontColor: Color(0xff9A9A9A),
                          //                             fontWeight: FontWeight.w400,
                          //                             fontSize: 8.sp,
                          //                           ),
                          //                           Container(
                          //                             height: 20.h,
                          //                             width: 50.w,
                          //                             decoration: BoxDecoration(
                          //                                 color: Color(0xffEC2547),
                          //                                 borderRadius:
                          //                                     BorderRadius.circular(3.r)),
                          //                             child: Padding(
                          //                               padding: const EdgeInsets.only(
                          //                                       left: 15,
                          //                                       right: 15,
                          //                                       top: 5,
                          //                                       bottom: 5)
                          //                                   .r,
                          //                               child: InkWell(
                          //                                 onTap: () {
                          //                                   Get.to(OrderDetails());
                          //                                 },
                          //                                 child: CustomText(
                          //                                   textAlign: TextAlign.center,
                          //                                   text: "Details",
                          //                                   fontColor: Color(0xffFFFFFF),
                          //                                   fontWeight: FontWeight.w600,
                          //                                   fontSize: 9.sp,
                          //                                 ),
                          //                               ),
                          //                             ),
                          //                           )
                          //                         ],
                          //                       ),
                          //                     ),
                          //                   ],
                          //                 ),
                          //               ],
                          //             ),
                          //           ),
                          //         ),
                          //       );
                          //     },
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
      },
    );
  }
}
