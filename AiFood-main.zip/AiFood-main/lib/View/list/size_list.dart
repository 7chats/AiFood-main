class SizeList {
  String text;

  SizeList({required this.text});
}

List<SizeList> sizeListModel = [
  SizeList(
    text: "Small",
  ),
  SizeList(
    text: "Medium",
  ),
  SizeList(
    text: "Large",
  ),
];
