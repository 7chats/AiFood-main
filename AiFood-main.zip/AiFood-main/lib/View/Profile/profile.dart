import 'dart:developer';

import 'package:aifood/View/Login/login_screen.dart';
import 'package:aifood/View/Shipping%20Address/shipping_address.dart';
import 'package:aifood/View/delete_account_screen.dart';
import 'package:aifood/controllers/home_controller.dart';
import 'package:aifood/user_prefs/user_prefs.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';

import '../Custom Widget/custom_text.dart';
import '../Edit_Profile/edit_profile.dart';
import '../Payment Methods/payment_method.dart';
import '../Setting/setting.dart';

class Profile extends StatefulWidget {
  const Profile({Key? key}) : super(key: key);

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  bool status = false;
  var homeController = Get.put(HomeController());
  gotcallf() async {
    bool? isLogin = await UserPreferences.getLoginCheck() ?? false;
    if(isLogin==false)
    {
      //log('datansdlaslasljlajlaajlaJLas');
      Get.to(LoginScreen());
    }
    else{
      //log('uytrtyuiolkjhgcvbnm');

      homeController.getProfile();
      homeController.profileLoading.value = false;
    }
  }
  @override
  initState() {
    gotcallf();
    // homeController.getProfile();
    // homeController.profileLoading.value = false;
    super.initState();
  }
  final String url =
      "https://www.freeprivacypolicy.com/live/049e9354-1bb5-4429-8f4e-d9c86ae6d95c";
  @override
  Widget build(BuildContext context) {
    return GetX<HomeController>(
      builder: (controller) {
        return homeController.profileLoading.value
            ? const CircularProgressIndicator()
            : Scaffold(
          backgroundColor: Colors.white,
          body: SafeArea(
            child: SingleChildScrollView(
              child: Container(
                padding:
                const EdgeInsets.only(left: 30, right: 30, top: 40).r,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        CustomText(
                          text: "Profile",
                          fontColor: const Color(0xff444444),
                          fontWeight: FontWeight.w700,
                          fontSize: 24.sp,
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Get.to(const EditProfile());
                          },
                          child: CustomText(
                            text: "Edit Profile",
                            fontColor: const Color(0xff5D3EBF),
                            fontWeight: FontWeight.w500,
                            fontSize: 14.sp,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      child: Row(
                        children: [
                          // Image.asset("assets/images/Profile.png",
                          SizedBox(
                            height: 87.h,
                            width: 87.w,
                            child: Image.network(
                              "${homeController.userProfile?.userData?.profilePic ??"https://aifood.citizensadgrace.com/public/images/icon.png"}",
                              height: 87.h,
                              width: 87.w,
                              fit: BoxFit.fill,
                            ),
                          ),
                          SizedBox(width: 15.w),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomText(
                                // text: "Alexandra",
                                text:
                                "${homeController.userProfile?.userData?.name??"Johan"}",
                                fontColor: const Color(0xff444444),
                                fontWeight: FontWeight.w500,
                                fontSize: 18.sp,
                              ),
                              SizedBox(height: 5.0.h),
                              CustomText(
                                // text: "(+1) 331 623 8413",
                                text:
                                "${homeController.userProfile?.userData?.phone ?? "--"}",
                                fontColor: const Color(0xff444444),
                                fontWeight: FontWeight.w400,
                                fontSize: 12.sp,
                              ),
                              SizedBox(height: 5.0.w),
                              Container(
                                child: Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: [
                                    const Icon(
                                      Icons.email_outlined,
                                      size: 20,
                                      color: Color(0xffC0C0C0),
                                    ),
                                    SizedBox(width: 8.w),
                                    SizedBox(
                                      width: Get.width * 0.47,
                                      child: CustomText(
                                        // text: "alexandra23@gmail.com",
                                        text:
                                        "${homeController.userProfile?.userData?.email ??"johan@gmail.com"}",
                                        fontColor:
                                        const Color(0xff444444),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12.sp,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20.h),
                    // GestureDetector(
                    //   onTap: () {},
                    //   child: Container(
                    //     padding:
                    //         const EdgeInsets.only(left: 15, right: 15).r,
                    //     height: 45.h,
                    //     width: 315.w,
                    //     decoration: BoxDecoration(
                    //       color: const Color(0xffffffff),
                    //       borderRadius: BorderRadius.circular(8.r),
                    //       boxShadow: const [
                    //         BoxShadow(
                    //           offset: Offset(0, 0),
                    //           blurRadius: 5.0,
                    //           color: Color(0xffE5E5E5),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment:
                    //           MainAxisAlignment.spaceBetween,
                    //       children: [
                    //         CustomText(
                    //           text: "Account info",
                    //           fontColor: const Color(0xff9098B1),
                    //           fontWeight: FontWeight.w400,
                    //           fontSize: 14.sp,
                    //         ),
                    //         const Icon(
                    //           Icons.arrow_forward_ios_outlined,
                    //           size: 20,
                    //           color: Color(0xffC0C0C0),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),
                    SizedBox(height: 12.h),
                    GestureDetector(
                      onTap: () {
                        Get.to(const ShippingAddress());
                      },
                      child: Container(
                        padding:
                        const EdgeInsets.only(left: 15, right: 15).r,
                        height: 45.h,
                        width: 315.w,
                        decoration: BoxDecoration(
                          color: const Color(0xfffffffff),
                          borderRadius: BorderRadius.circular(8.r),
                          boxShadow: const [
                            BoxShadow(
                              offset: Offset(0, 0),
                              blurRadius: 5.0,
                              color: Color(0xffE5E5E5),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              text: "My Addresses",
                              fontColor: const Color(0xff9098B1),
                              fontWeight: FontWeight.w400,
                              fontSize: 14.sp,
                            ),
                            const Icon(
                              Icons.arrow_forward_ios_outlined,
                              size: 20,
                              color: Color(0xffC0C0C0),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 12.h),
                    // GestureDetector(
                    //   onTap: () {
                    //     Get.to(const PaymentMethod());
                    //   },
                    //   child: Container(
                    //     padding:
                    //         const EdgeInsets.only(left: 15, right: 15).r,
                    //     height: 45.h,
                    //     width: 315.w,
                    //     decoration: BoxDecoration(
                    //       color: const Color(0xfffffffff),
                    //       borderRadius: BorderRadius.circular(8.r),
                    //       boxShadow: const [
                    //         BoxShadow(
                    //           offset: Offset(0, 0),
                    //           blurRadius: 5.0,
                    //           color: Color(0xffE5E5E5),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment:
                    //           MainAxisAlignment.spaceBetween,
                    //       children: [
                    //         CustomText(
                    //           text: "Payment Methods",
                    //           fontColor: const Color(0xff9098B1),
                    //           fontWeight: FontWeight.w400,
                    //           fontSize: 14.sp,
                    //         ),
                    //         const Icon(
                    //           Icons.arrow_forward_ios_outlined,
                    //           size: 20,
                    //           color: Color(0xffC0C0C0),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),
                    SizedBox(height: 12.h),
                    // GestureDetector(
                    //   onTap: () {},
                    //   child: Container(
                    //     padding:
                    //         const EdgeInsets.only(left: 15, right: 15).r,
                    //     height: 45.h,
                    //     width: 315.w,
                    //     decoration: BoxDecoration(
                    //       color: const Color(0xfffffffff),
                    //       borderRadius: BorderRadius.circular(8.r),
                    //       boxShadow: const [
                    //         BoxShadow(
                    //           offset: Offset(0, 0),
                    //           blurRadius: 5.0,
                    //           color: Color(0xffE5E5E5),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment:
                    //           MainAxisAlignment.spaceBetween,
                    //       children: [
                    //         CustomText(
                    //           text: "Billing History",
                    //           fontColor: const Color(0xff9098B1),
                    //           fontWeight: FontWeight.w400,
                    //           fontSize: 14.sp,
                    //         ),
                    //         const Icon(
                    //           Icons.arrow_forward_ios_outlined,
                    //           size: 20,
                    //           color: Color(0xffC0C0C0),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),
                    SizedBox(height: 12.h),
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        padding:
                        const EdgeInsets.only(left: 15, right: 15).r,
                        height: 45.h,
                        width: 315.w,
                        decoration: BoxDecoration(
                          color: const Color(0xfffffffff),
                          borderRadius: BorderRadius.circular(8.r),
                          boxShadow: const [
                            BoxShadow(
                              offset: Offset(0, 0),
                              blurRadius: 5.0,
                              color: Color(0xffE5E5E5),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              text: "Notifications",
                              fontColor: const Color(0xff9098B1),
                              fontWeight: FontWeight.w400,
                              fontSize: 14.sp,
                            ),
                            FlutterSwitch(
                              activeColor: const Color(0xff5D3EBF),
                              width: 25.0.w,
                              height: 16.0.h,
                              valueFontSize: 10.0,
                              toggleSize: 10.0,
                              value: status,
                              borderRadius: 8.0,
                              //  padding: 8.0,
                              showOnOff: false,
                              onToggle: (val) {
                                setState(() {
                                  status = val;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 12.h),
                    // GestureDetector(
                    //   onTap: () {
                    //     Get.to(const Setting());
                    //   },
                    //   child: Container(
                    //     padding:
                    //     const EdgeInsets.only(left: 15, right: 15).r,
                    //     height: 45.h,
                    //     width: 315.w,
                    //     decoration: BoxDecoration(
                    //       color: const Color(0xfffffffff),
                    //       borderRadius: BorderRadius.circular(8.r),
                    //       boxShadow: const [
                    //         BoxShadow(
                    //           offset: Offset(0, 0),
                    //           blurRadius: 5.0,
                    //           color: Color(0xffE5E5E5),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment:
                    //       MainAxisAlignment.spaceBetween,
                    //       children: [
                    //         CustomText(
                    //           text: "Settings",
                    //           fontColor: const Color(0xff9098B1),
                    //           fontWeight: FontWeight.w400,
                    //           fontSize: 14.sp,
                    //         ),
                    //         const Icon(
                    //           Icons.arrow_forward_ios_outlined,
                    //           size: 20,
                    //           color: Color(0xffC0C0C0),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),
                    SizedBox(height: 12.h),
                    // GestureDetector(
                    //   onTap: () {},
                    //   child: Container(
                    //     padding:
                    //         const EdgeInsets.only(left: 15, right: 15).r,
                    //     height: 45.h,
                    //     width: 315.w,
                    //     decoration: BoxDecoration(
                    //       color: const Color(0xfffffffff),
                    //       borderRadius: BorderRadius.circular(8.r),
                    //       boxShadow: const [
                    //         BoxShadow(
                    //           offset: Offset(0, 0),
                    //           blurRadius: 5.0,
                    //           color: Color(0xffE5E5E5),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment:
                    //           MainAxisAlignment.spaceBetween,
                    //       children: [
                    //         CustomText(
                    //           text: "Support",
                    //           fontColor: const Color(0xff9098B1),
                    //           fontWeight: FontWeight.w400,
                    //           fontSize: 14.sp,
                    //         ),
                    //         const Icon(
                    //           Icons.arrow_forward_ios_outlined,
                    //           size: 20,
                    //           color: Color(0xffC0C0C0),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),
                    SizedBox(height: 12.h),
                    Container(
                      padding:
                      const EdgeInsets.only(left: 15, right: 15).r,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              // CustomText(

                              // ),
                              GestureDetector(
                                onTap: () async {
                                  await launchUrl(Uri.parse(url));
                                },
                                child: CustomText(
                                  text: "About us",
                                  textAlign: TextAlign.start,
                                  fontColor: const Color(0xff8F9394),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14.sp,
                                ),
                              )
                            ],
                          ),
                          SizedBox(height: 12.h),
                          GestureDetector(
                            onTap: () async {
                              await launchUrl(Uri.parse(url));
                            },
                            child: CustomText(
                              text: "Contact us",
                              textAlign: TextAlign.start,
                              fontColor: const Color(0xff8F9394),
                              fontWeight: FontWeight.w500,
                              fontSize: 14.sp,
                            ),
                          ),
                          SizedBox(height: 12.h),
                          GestureDetector(
                            onTap: () async {
                              await launchUrl(Uri.parse(url));
                            },
                            child: CustomText(
                              text: "Help",
                              textAlign: TextAlign.start,
                              fontColor: const Color(0xff8F9394),
                              fontWeight: FontWeight.w500,
                              fontSize: 14.sp,
                            ),
                          ),
                          SizedBox(height: 12.h),
                          GestureDetector(
                            onTap: () async {
                              await launchUrl(Uri.parse(url));
                            },
                            child: CustomText(
                              text: "Privacy Policy",
                              textAlign: TextAlign.start,
                              fontColor: const Color(0xff8F9394),
                              fontWeight: FontWeight.w500,
                              fontSize: 14.sp,
                            ),
                          ),
                          SizedBox(height: 12.h),
                          GestureDetector(
                            onTap: () =>
                                Get.to(DeleteAccountScreen()),
                            child: CustomText(
                              text: "Delete my Account",
                              textAlign: TextAlign.start,
                              fontColor: const Color(0xff8F9394),
                              fontWeight: FontWeight.w500,
                              fontSize: 14.sp,
                            ),
                          ),

                          SizedBox(height: 12.h),

                          // CustomText(
                          //   text: "Terms and conditions",
                          //   fontColor: const Color(0xff8F9394),
                          //   fontWeight: FontWeight.w500,
                          //   fontSize: 14.sp,
                          // ),
                          // SizedBox(height: 12.h),
                          GestureDetector(
                            onTap: () {
                              UserPreferences.setLoginCheck(false);
                              Get.offAll(LoginScreen());
                            },
                            child: CustomText(
                              text: "Logout",
                              fontColor: const Color(0xff8F9394),
                              fontWeight: FontWeight.w500,
                              fontSize: 14.sp,
                            ),
                          ),
                          SizedBox(height: 12.h),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}


