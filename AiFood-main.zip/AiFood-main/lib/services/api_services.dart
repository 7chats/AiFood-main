import 'dart:convert';

import 'package:aifood/base_url/base_url.dart';
import 'package:aifood/models/cart_item.dart';
import 'package:aifood/models/customer_reviews.dart';
import 'package:aifood/models/make_checkout.dart';
import 'package:aifood/models/payment_cards.dart';
import 'package:aifood/models/shipping_addresses.dart';
import 'package:aifood/models/user_profile.dart';
import 'package:aifood/user_prefs/user_prefs.dart';
import 'package:aifood/utils/utils.dart';
import 'package:http/http.dart' as http;

class ApiServices {
  UserProfile? userProfile;
  ApiServices() {
    String? data = UserPreferences.getUserData();
    if(data!=null)
      {
        userProfile = UserProfile.fromJson(jsonDecode(data!));
      }
    else
      {

      }
  }

  /// 1.
  static Future<bool?> register(String? name, String? email, String? password,
      String? phone, String? image) async {
    var uri = '$baseUrl/api/register';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'name': '$name', // 'Muhammad Ismail',
      'email': '$email', //  'ismail@gmail.com',
      'phone': '$phone', // '03002109329',
      'password': '$password', //  '12345678'
    });
    if (image != null) {
      var file = await http.MultipartFile.fromPath('profile_pic', image);
      request.files.add(file);
    }
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      var data = await response.stream.bytesToString();
      dprint(data);
      await UserPreferences.setUserData(data);
      await UserPreferences.setLoginCheck(true);
      return true;
    } else {
      dprint(response.reasonPhrase);
      return false;
    }
  }

  /// 2.
  static Future<bool?> login(String? email, String? password) async {
    var uri = '$baseUrl/api/login';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'email': '$email', //  'ismail@gmail.com',
      'password': '$password', //  '12345678'
    });
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      var data = await response.stream.bytesToString();
      dprint(data);
      await UserPreferences.setUserData(data);
      await UserPreferences.setLoginCheck(true);
      return true;
    } else {
      dprint(response.reasonPhrase);
      return false;
    }
  }

  ///
  Future<bool?> editProfile(UserData? userData) async {
    var uri = '$baseUrl/api/edit_user_profile';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '${userData!.apiToken}',
      'user_id': '${userProfile!.userData!.id}', // '9',
      'name': '${userData.name}', // 'Muhammad Ismail',
      'email': '${userData.email}', // 'ismail@gmail.com',
      'phone': '${userData.phone}', // '03010112109',
      'password': '${userData.deviceToken}', // '12345678'
    });
    if (userData.profilePic != null) {
      request.files.add(await http.MultipartFile.fromPath(
          'profile_pic', '${userData.profilePic}'));
    }
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      var data = await response.stream.bytesToString();
      dprint(data);
      await UserPreferences.setUserData(data);
      return true;
    } else {
      dprint(response.reasonPhrase);
      return false;
    }
  }

  Future<bool?> changePassword(String? password) async {
    var uri = '$baseUrl/api/change_password';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '${userProfile!.userData!.apiToken}',
      'password': '$password', // '87654321'
    });
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///
  Future<bool?> logOut() async {
    var apiToken = userProfile!.userData!.apiToken;
    var uri = '$baseUrl/api/logout?api_token=$apiToken';
    var request = http.MultipartRequest('GET', Uri.parse(uri));
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///
  Future<bool?> deleteAccount() async {
    var uri = '$baseUrl/api/delete_account';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '${userProfile!.userData!.apiToken}',
      'user_id': '${userProfile!.userData!.id}', // '9',
    });
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  /// 3.
  Future<String?> getBanners() async {
    var uri = '$baseUrl/api/banners';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  /// 4.
  Future<String?> getCategories() async {
    var uri = '$baseUrl/api/categories';
    var request = http.MultipartRequest('GET', Uri.parse(uri));
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  /// 5.
  Future<String?> getSuggestedProducts() async {
    var uri = '$baseUrl/api/suggested_products';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  /// 6.
  Future<String?> getProductDetail(String? productId) async {
    var uri = '$baseUrl/api/get_product_details';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'product_id': '$productId', // '46',
    });
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<String?> getAllCoupons() async {
    var apiToken = userProfile!.userData!.apiToken;
    var uri = '$baseUrl/api/coupons?api_token=$apiToken';
    var request = http.MultipartRequest('GET', Uri.parse(uri));
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<String?> applyCouponCode(String? couponCode, String? amount) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uri = '$baseUrl/api/apply_code';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '${userProfile!.userData!.id}', // '29',
      'coupon_code': '$couponCode', // 'NewYear2023',
      'total_amount': '$amount', // '100'
    });
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  /// 6.1
  Future<String?> getRestaurantDetail(String? marketId) async {
    var uri = '$baseUrl/api/get_restaurant_details';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'market_id': '$marketId', // '46',
    });
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  /// 7.0
  Future<String?> getNearByRestaurants() async {
    var uri = '$baseUrl/api/nearby_restaurants';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  /// 7.1
  Future<String?> getMarketDetail(String? marketId) async {
    var uri = '$baseUrl/api/get_restaurant_details';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'user_id': '${userProfile!.userData!.id}', // '9',
      'market_id': '$marketId', // '25',
    });
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  /// 8.
  Future<bool?> addToFavouriteProducts(String? productId) async {
    var uri = '$baseUrl/api/favorites';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '${userProfile!.userData!.apiToken}',
      'user_id': '${userProfile!.userData!.id}', // '9',
      'product_id': '$productId', // '46',
    });
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  /// 9.
  Future<String?> getFavouriteProducts() async {
    var apiToken = userProfile!.userData!.apiToken;
    var url = '$baseUrl/api/favorites?api_token=$apiToken';
    var request = http.MultipartRequest('GET', Uri.parse(url));
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  /// 10.
  Future<bool?> removeFromFavourites(String? productId) async {
    var apiToken = userProfile!.userData!.apiToken;
    var url = '$baseUrl/api/favorites/$productId?api_token=$apiToken';
    var request = http.MultipartRequest('DELETE', Uri.parse(url));
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  /// 11.
  Future<bool?> addToCart(CartItem? cartItem) async {
    // String? productId, String? quantity, var extras) async {
    var apiToken = userProfile!.userData!.apiToken;
    var url = '$baseUrl/api/add_to_cart';
    var request = http.MultipartRequest('POST', Uri.parse(url));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '${userProfile!.userData!.id}', // '9',
      'product_id': '${cartItem!.productId}', // '46',
      'quantity': '${cartItem.quantity}', // '2',
      'delivery_charges': '${cartItem.deliveryCharges}', // '2',
      'size': '${cartItem.size}', // 'Small',
      'special_instructions':
          '${cartItem.specialInstructions}', // 'Add extras cheese',
      'extras': jsonEncode(cartItem.extras!.map((e) => e.toJson()).toList()),
      // extras
      // '[\n    {\n        "extras_id": 92,\n        "extras_quantity": 2\n    },\n    {\n        "extras_id": 93,\n        "extras_quantity": 1\n    }\n]'
    });
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///
  Future<bool?> removeProductFromCart(String? cartId) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/remove_product_from_cart';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll(
        {'api_token': '$apiToken', 'user_id': '$uid', 'cart_id': '$cartId'});
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///
  Future<String?> updateCartProduct(cartId, CartItem? cartItem) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/update_cart_product';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '$uid',
      'cart_id': '$cartId',
      'product_id': '${cartItem!.productId}', // '46',
      'quantity': '${cartItem.quantity}', // '2',
      'delivery_charges': '${cartItem.deliveryCharges}', // '2',
      'size': '${cartItem.size}', // 'Small',
      'special_instructions':
          '${cartItem.specialInstructions}', // 'Add extras cheese',
      'extras': jsonEncode(cartItem.extras!.map((e) => e.toJson()).toList()),
      // 'extras':
      //     '[\n    {\n        "extras_id": 92,\n        "extras_quantity": 2\n    },\n    {\n        "extras_id": 93,\n        "extras_quantity": 1\n    }\n]'
    });
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<String?> getCartDetails() async {
    var apiToken = userProfile!.userData!.apiToken;
    var uri = '$baseUrl/api/get_cart_details';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '${userProfile!.userData!.id}',
    });
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  // ///
  // Future<String?> getCoupens(String? productId) async {
  //   var apiToken = userProfile!.userData!.apiToken;
  //   var url = '$baseUrl/api/coupons?api_token=$apiToken';
  //   var request = http.MultipartRequest('GET', Uri.parse(url));
  //   http.StreamedResponse response = await request.send();
  //   return await dataResponse(response);
  // }

  ///
  Future<String?> checkOut(MakeCheckout checkout) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/checkout';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '$uid',
      'market_id': '${checkout.marketId}', // '29',
      'items': jsonEncode(checkout.items!.map((e) => e.toJson()).toList()),
      // '[\n    {\n        "product_id": 47,\n        "product_quantity": 2,\n        "product_price": 16.19,\n        "product_size": "Medium",\n        "product_special_instructions": "Add Extra Cheese",\n        "extras": [\n            {\n                "extras_id": 92,\n                "extras_price": 6,\n                "extras_quantity": 2\n            },\n            {\n                "extras_id": 93,\n                "extras_price": 4,\n                "extras_quantity": 1\n            }\n        ]\n    }\n]',
      'shipping_address_id': '${checkout.shippingAddressId}', // '1',
      'payment_method_type':
          '${checkout.paymentMethodType}', //'Cash on Delivery',
      'item_total': '${checkout.itemTotal}', // '32.38',
      'discount': '${checkout.discount}', // '0.00',
      'taxes': '${checkout.taxes}', // '2.62',
      'delivery_charges': '${checkout.deliveryCharges}', // '5.00',
      'order_total': '${checkout.orderTotal}', //'40.00',
      'promo_code': '${checkout.promoCode}', //''
    });
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<String?> getShippingAddresses() async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/get_shipping_address';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({'api_token': '$apiToken', 'user_id': '$uid'});
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<bool?> activeShippingAddresses(addressId) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/use_as_shipping_address';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '$uid',
      'shipping_id': '$addressId', // '1',
    });
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///
  Future<bool?> addShippingAddress(Address address) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/add_shipping_address';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '$uid',
      'full_name': '${address.fullName}', // 'Mukhtar Abbas',
      'mobile': '${address.mobile}', // '+92 333 1751075',
      'address': '${address.address}', // 'C block Millat Town Faisalabad',
      'city': '${address.city}', // 'Faisalabad',
      'state': '${address.state}', // 'Pakistan',
      'zip_code': '${address.zipcode}', // '78000',
      'country': '${address.country}', // 'Pakistan'
    });
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///
  Future<bool?> addPaymentCard(Card card) async {
    var jsonresponse =
        '''{"success": true,"message": "Payment card added successfully","data": {"user_id": "23"}}''';
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/add_payment_card';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '$uid',
      'card_holder_name': '${card.id}', // 'Jane Deo',
      'card_number': '${card.lastFourCardDigits}', // '12345678912345',
      'expire_date': '${card.expireDate}', // '12/23',
      'cvv': '${card.cvv}', // '123'
    });
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///
  Future<String?> getAllPaymentCards() async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/get_payment_cards';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({'api_token': '$apiToken', 'user_id': '$uid'});
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<bool?> activePaymentCard(int? cardId) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/use_as_payment_card';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll(
        {'api_token': '$apiToken', 'user_id': '$uid', 'card_id': '$cardId'});
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///
  Future<String?> getDeliveredOrders() async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/delivered_orders';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({'api_token': '$apiToken', 'user_id': '$uid'});
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<String?> getProcessingOrders() async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/processing_orders';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({'api_token': '$apiToken', 'user_id': '$uid'});
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<String?> getCancelledOrders() async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/cancelled_orders';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({'api_token': '$apiToken', 'user_id': '$uid'});
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<String?> getOrderDetail(String? orderId) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/order_detail';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '$uid',
      'order_id': '$orderId', // '8',
    });
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<bool?> cancelOrder(String? orderId) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/cancel_order';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '$uid',
      'order_id': '$orderId', // '8',
    });
    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///
  Future<String?> trackOrder(String? orderId) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uid = userProfile!.userData!.id;
    var uri = '$baseUrl/api/track_order';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '$uid',
      'order_id': '$orderId', // '8',
    });
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  ///
  Future<bool?> orderRating(Review? review) async {
    var apiToken = userProfile!.userData!.apiToken;
    var uri = '$baseUrl/api/order_rating';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'api_token': '$apiToken',
      'user_id': '${review!.userId}', // 3
      'order_id': '${review.orderId}', // '8',
      'rating': '${review.rating}', // '4',
      'review': '${review.review}', // 'Good service and quality food'
    });
    if (review.reviewPhotos!.isNotEmpty) {
      request.files.add(await http.MultipartFile.fromPath(
          'photos[]', review.reviewPhotos![0]));
    }
    if (review.reviewPhotos!.length >= 2) {
      request.files.add(await http.MultipartFile.fromPath(
          'photos[]', review.reviewPhotos![1]));
    }
    if (review.reviewPhotos!.length >= 3) {
      request.files.add(await http.MultipartFile.fromPath(
          'photos[]', review.reviewPhotos![2]));
    }
    if (review.reviewPhotos!.length >= 4) {
      request.files.add(await http.MultipartFile.fromPath(
          'photos[]', review.reviewPhotos![3]));
    }

    http.StreamedResponse response = await request.send();
    return await checkResponse(response);
  }

  ///

  Future<String?> customerReviews(String? userId) async {
    var apiToken = userProfile!.userData!.apiToken;

    var uri = '$baseUrl/api/customer_reviews';
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({'api_token': '$apiToken', 'user_id': '$userId'});
    http.StreamedResponse response = await request.send();
    return await dataResponse(response);
  }

  //////////////////////////////////////////////////////////////////////////////
  /// Response Functions
  static Future<String?> dataResponse(http.StreamedResponse response) async {
    if (response.statusCode == 200) {
      var data = await response.stream.bytesToString();
      dprint(data);
      return data;
    } else {
      dprint(response.reasonPhrase);
      return null;
    }
  }

  ///
  static Future<bool?> checkResponse(http.StreamedResponse response) async {
    if (response.statusCode == 200) {
      var data = await response.stream.bytesToString();
      dprint(data);
      return true;
    } else {
      dprint(response.reasonPhrase);
      return false;
    }
  }
}
