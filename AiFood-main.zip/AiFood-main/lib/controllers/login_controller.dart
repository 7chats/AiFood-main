import 'package:get/get.dart';

class LoginController extends GetxController {
  var loading = false.obs;
  var otp = "".obs;
  var verificationId = "".obs;
  var email = "".obs;
  var phone = "".obs;
  var password = "".obs;
}
