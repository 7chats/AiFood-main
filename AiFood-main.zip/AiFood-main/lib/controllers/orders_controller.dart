import 'dart:convert';

import 'package:aifood/models/customer_reviews.dart';
import 'package:aifood/models/order_detail.dart';
import 'package:aifood/models/orders.dart';
import 'package:aifood/services/api_services.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

class OrdersController extends GetxController {
  var loading = true.obs;
  var odLoading = true.obs;
  var reviewLoading = true.obs;
  var addReviewLoading = false.obs;

  Orders? deliveredOrders, processingOrders, cancelledOrders;
  Future getAllOrders() async {
    ///
    var dData = await ApiServices().getDeliveredOrders();
    deliveredOrders = Orders.fromJson(jsonDecode(dData!));

    ///
    var pData = await ApiServices().getProcessingOrders();
    processingOrders = Orders.fromJson(jsonDecode(pData!));

    ///
    var cData = await ApiServices().getCancelledOrders();
    cancelledOrders = Orders.fromJson(jsonDecode(cData!));
    loading.value = false;
  }

  OrderDetail? orderDetail;
  String? currentOrderId;
  Future getOrderDetail() async {
    odLoading.value = true;
    var data = await ApiServices().getOrderDetail(currentOrderId);
    orderDetail = OrderDetail.fromJson(jsonDecode(data!));
    odLoading.value = false;
  }

  CustomerReviews? customerReviews;
  String? customerId;
  Future getCustomerReviews() async {
    reviewLoading.value = true;
    var data = await ApiServices().customerReviews(customerId);
    customerReviews = CustomerReviews.fromJson(jsonDecode(data!));
    calculateRatings(customerReviews);
    reviewLoading.value = false;
  }

  var averageRating = 0.0;
  var oneRatings = 0;
  var twoRatings = 0;
  var threeRatings = 0;
  var fourRatings = 0;
  var fiveRatings = 0;
  var oneWidth = 0.0;
  var twoWidth = 0.0;
  var threeWidth = 0.0;
  var fourWidth = 0.0;
  var fiveWidth = 0.0;

  calculateRatings(CustomerReviews? customerReviews) {
    averageRating = 0.0;
    oneRatings = 0;
    twoRatings = 0;
    threeRatings = 0;
    fourRatings = 0;
    fiveRatings = 0;
    //
    for (var revu in customerReviews!.data!.reviews!) {
      //
      var rating = double.parse(revu.rating!);
      averageRating = averageRating + rating;

      ///
      if (revu.rating == '1') {
        oneRatings++;
      }

      ///
      if (revu.rating == '2') {
        twoRatings++;
      }

      ///
      if (revu.rating == '3') {
        threeRatings++;
      }

      ///
      if (revu.rating == '4') {
        fourRatings++;
      }

      ///
      if (revu.rating == '5') {
        fiveRatings++;
      }
    }

    if (customerReviews.data!.reviews!.isNotEmpty) {
      averageRating = averageRating / customerReviews.data!.reviews!.length;
    }
  }

  Review? review = Review(reviewPhotos: []);
  Future<bool?> addReview() async {
    addReviewLoading.value = true;
    review!.userId = customerId;
    review!.orderId = currentOrderId; // orderDetail!.orderData!.id;
    var check = await ApiServices().orderRating(review);
    addReviewLoading.value = false;
    return check;
  }

  ///
  pickPhotos() async {
    var picker = ImagePicker();
    final pickedFiles = await picker.pickMultiImage();
    for (var file in pickedFiles) {
      review!.reviewPhotos!.add(file.path);
    }
  }
}
