import 'dart:convert';

import 'package:aifood/models/banners.dart';
import 'package:aifood/models/categories.dart';
import 'package:aifood/models/nearby_restaurants.dart';
import 'package:aifood/models/product_detail.dart';
import 'package:aifood/models/restaurant_detail.dart';
import 'package:aifood/models/suggested_products.dart';
import 'package:aifood/models/user_profile.dart';
import 'package:aifood/services/api_services.dart';
import 'package:aifood/user_prefs/user_prefs.dart';
import 'package:aifood/utils/location_utils.dart';
import 'package:get/get.dart';

class HomeController extends GetxController {
  var loading = true.obs;
  var pdLoading = true.obs; // For Product Detail
  var rdLoading = true.obs; // For Restaurant Detail
  var profileLoading = true.obs;
  var editProfileLoading = false.obs;
  var address = "".obs;

  Banners? banners;

  Future getBanners() async {
    var data = await ApiServices().getBanners();
    banners = Banners.fromJson(jsonDecode(data!));
  }

  Categories? categories;
  Future getCategories() async {
    var data = await ApiServices().getCategories();
    categories = Categories.fromJson(jsonDecode(data!));
  }

  SuggestedProducts? suggestedProducts;
  Future getSuggestedProducts() async {
    var data = await ApiServices().getSuggestedProducts();
    suggestedProducts = SuggestedProducts.fromJson(jsonDecode(data!));
  }

  NearByRestaurants? nearByRestaurants;
  Future getNearByRestaurants() async {
    var data = await ApiServices().getNearByRestaurants();
    nearByRestaurants = NearByRestaurants.fromJson(jsonDecode(data!));
  }

  Future getCurrentLocation() async {
    var locationAddress = await LocationUtils.addressFromCurrentLocation();
    address.value = locationAddress!;
  }

  getHomeData() async {
    await getProfile();
    await getBanners();
    await getCategories();
    await getSuggestedProducts();
    await getNearByRestaurants();
    loading.value = false;
    await getCurrentLocation();
    loading.value = false;
  }

  var cpLoading = true.obs;
  var categoryId = '';
  Category? category;
  List<Product>? categoryProducts = [];
  getCategoryProducts() {
    categoryProducts = [];
    for (var product in suggestedProducts!.products!) {
      if (product.categoryId == categoryId) {
        categoryProducts!.add(product);
      }
    }
    cpLoading.value = false;
  }

  ProductDetail? productDetail;
  String? currentProductId;
  String? currentSize;
  Future getProductDetail() async {
    var data = await ApiServices().getProductDetail(currentProductId);
    productDetail = ProductDetail.fromJson(jsonDecode(data!));
    if (productDetail!.detail!.productSize!.isNotEmpty) {
      currentSize = productDetail!.detail!.productSize!.first;
    }
  }

  getProductDetailScreenData() async {
    pdLoading.value = true;
    await getProductDetail();
    pdLoading.value = false;
  }

  Future<bool?> addToFavorites(String? productId) async {
    var check = await ApiServices().addToFavouriteProducts(productId);
    return check;
  }

  //
  ///
  RestaurantDetails? restaurantDetails;
  String? currentRestaurantId;
  String? currentCategoryId;
  getStoreDetail() async {
    rdLoading.value = true;
    var data = await ApiServices().getRestaurantDetail(currentRestaurantId);
    restaurantDetails = RestaurantDetails.fromJson(jsonDecode(data!));
    if (restaurantDetails!.data!.categoryList!.isNotEmpty) {
      currentCategoryId = restaurantDetails!.data!.categoryList!.first.id;
    }
    rdLoading.value = false;
  }

  ///
  UserProfile? userProfile;
  UserData? userData = UserData();
  getProfile() {
    profileLoading.value = true;
    var data = UserPreferences.getUserData();
    if(data!=null){
      userProfile = UserProfile.fromJson(jsonDecode(data!));
      userData!.name = userProfile!.userData!.name;
      userData!.email = userProfile!.userData!.email;
      userData!.phone = userProfile!.userData!.phone;
      // userData!.email = userProfile!.userData!.email;
      profileLoading.value = false;
    }
    else
      {
        //userProfile = UserProfile.fromJson(jsonDecode(data!));
        userData!.name = userProfile?.userData?.name??"";
        userData!.email = userProfile?.userData?.email??"";
        userData!.phone = userProfile?.userData?.phone??"";
        // userData!.email = userProfile!.userData!.email;
        profileLoading.value = false;
      }
  }

  editProfile() async {
    var res = await ApiServices().editProfile(userData!);
    return res;
  }
}
